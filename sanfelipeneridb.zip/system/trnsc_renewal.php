<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Renewal of Contract
        <small>Control Panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Control Panel</li>
        <li class="active">Renewal of Contract</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active">
                <a href="#tab_member" data-toggle="tab">Yearly</a>
                </li>
              <li class="">
                <a href="#tab_tricycle" data-toggle="tab"></a>
            </li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_member">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_yearly_registration" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Expiration Date</th>
                                        <th>Payment Date</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Expiration Date</th>
                                        <th>Payment Date</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_tricycle">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_renewal_franchise" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Brand - Plate No.</th>
                                        <th>Driver</th>
                                        <th>Expiration Date</th>
                                        <th>Payment Date</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Brand - Plate No.</th>
                                        <th>Driver</th>
                                        <th>Expiration Date</th>
                                        <th>Payment Date</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
              <!-- /.tab-pane -->
            <!-- /.tab-content -->
          </div>
        
    </section>

</div>
<?php include('common/footer.php'); ?>
<?php include('modal/transaction/renew_modal.php'); ?>
<script type="text/javascript">
<?php include('common/js/renewal.js'); ?>
</script>