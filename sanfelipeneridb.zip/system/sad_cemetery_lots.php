<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Expiring Cemetery Lots
        <small>Control Panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Control Panel</li>
        <li class="active">Expiring Cemetery Lots</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="hide"><a href="#tab_toda_name" data-toggle="tab">Toda Name</a></li>
              <li class="hide"><a href="#tab_user_admin" data-toggle="tab">User Admin</a></li>
              <li class="hide"><a href="#tab_officer" data-toggle="tab">Toda Officer</a></li>
              <li class="hide"><a href="#tab_enforcer" data-toggle="tab">Enforcer</a></li>
            </ul>
            <div class="tab-content">
              <!-- /.tab-pane -->
              <div class="tab-pane active" id="tab_user_admin">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="pull-right">
                            <select id="months-expiry" style="padding: 5px">
                                <option value="3">3 months</option>
                                <option value="6">6 months</option>
                                <option value="9">9 months</option>
                                <option value="12">12 months</option>
                            </select>
                        </div>
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_expiring_lots" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
            </div>
            <!-- /.tab-content -->
          </div>
        
    </section>

</div>
<?php include('common/footer.php'); ?>
<script type="text/javascript">
<?php include('common/js/sad_functions.js'); ?>
</script>