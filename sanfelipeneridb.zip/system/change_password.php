<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Change Password
            <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Change Password</li>
        </ol>
    </section>

    <div class="m-t-10">
        <div class="login-box">
            <div class="login-box-body">
                <div class="form-group has-feedback">
                    <input type="text" id="username" class="form-control" 
                    value="<?php echo 'USER-'.$_SESSION['user_id']; ?>" disabled>
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" id="old-password" class="form-control" placeholder="Old Password">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <small></small>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" id="new-password" class="form-control" placeholder="New Password">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <small></small>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" id="confirm-password" class="form-control" placeholder="Confirm Password">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <small></small>
                </div>
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button id="change-pass" class="btn btn-primary btn-block btn-flat">Change Password</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('common/footer.php'); ?>
<script type="text/javascript">
<?php include('common/js/change_password.js'); ?>
</script>