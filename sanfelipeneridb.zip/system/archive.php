<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Archive Items
        <small>Control Panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Control Panel</li>
        <li class="active">Archive Items</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="hide"><a href="#tab_toda_name" data-toggle="tab">Toda Name</a></li>
              <li class=""><a href="#tab_user_admin" data-toggle="tab">User Admin</a></li>
              <li class="hide"><a href="#tab_officer" data-toggle="tab">Toda Officer</a></li>
              <li class="hide"><a href="#tab_enforcer" data-toggle="tab">Enforcer</a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_toda_name">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_archive_toda" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_user_admin">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_archive_user" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_officer">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_archive_officer" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
              <div class="tab-pane" id="tab_enforcer">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view_archive_enforcer" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Deleted By</th>
                                        <th>Date Deleted</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
        
    </section>

</div>
<?php include('common/footer.php'); ?>
<?php include('modal/archive_modal.php'); ?>
<script type="text/javascript">
<?php include('common/js/archive.js'); ?>
</script>