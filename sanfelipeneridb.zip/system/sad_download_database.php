<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Download Database Backup
        <small>Control Panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Control Panel</li>
        <li class="active">Download Database Backup</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <br>
        <button id="download-database">DOWNLOAD DATABASE BACKUP</button>
    </section>

</div>
<?php include('common/footer.php'); ?>
<script type="text/javascript">
<?php include('common/js/sad_functions.js'); ?>
</script>