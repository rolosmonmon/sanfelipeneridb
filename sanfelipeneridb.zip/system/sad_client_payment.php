<?php include('common/header.php'); ?>
<style type="text/css">
    .mtl-25 {
        margin-top: 25px;
        margin-left: 35px;
    }
</style>
<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Client's Payment
        <small>Control Panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Control Panel</li>
        <li class="active">Client's Payment</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="hide"><a href="#tab_toda_name" data-toggle="tab">Toda Name</a></li>
              <li class="hide"><a href="#tab_user_admin" data-toggle="tab">User Admin</a></li>
              <li class="hide"><a href="#tab_officer" data-toggle="tab">Toda Officer</a></li>
              <li class="hide"><a href="#tab_enforcer" data-toggle="tab">Enforcer</a></li>
            </ul>
            <div class="tab-content">
                <div class="col-sm-12">
                    <button class="btn btn-primary" id ="monthly-report" style="width: 100%;">
                            Show Yearly Report
                    </button>
                </div>
              <!-- /.tab-pane -->
              <div class="tab-pane active" id="tab_user_admin">
                <div class="row">
                    <div class="col-xs-12">
                        <!-- <div class="pull-right">
                            <select id="months-expiry" style="padding: 5px">
                                <option value="3">3 months</option>
                                <option value="6">6 months</option>
                                <option value="9">9 months</option>
                                <option value="12">12 months</option>
                            </select>
                        </div> -->
                        <!-- <div class="box"> -->
                            <div class="box-body">
                                <table id="view-client-payment" class="table table-bordered table-hover">
                                    <thead>
                                        <th>Name</th>
                                        <th>Payment Date</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                    <tfoot>
                                        <th>Name</th>
                                        <th>Payment Date</th>
                                        <th>Amount</th>
                                        <th>Action</th>
                                    </tfoot>
                                </table>
                            </div>
                        <!-- </div> -->
                    </div>
                </div>
              </div>
            </div>
            <!-- /.tab-content -->
          </div>
        
    </section>

</div>
<?php include('common/footer.php'); ?>
<script type="text/javascript">
<?php include('common/js/sad_functions.js'); ?>
</script>


<!-- MODAL -->
<div class="modal fade" id="modal-monthly-report">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Yearly Report</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12">
                        <select id="select-year" class="form-control" style="width: 100%">
                            <?php for ($i=2010; $i <=date(Y) ; $i++) { ?> 
                                <option value="<?php echo $i;?>"><?php echo $i;?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">Original Contract</label>
                    <div class="col-sm-6" id="original-contract">PHP 0.00</div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">Valid ID</label>
                    <div class="col-sm-6" id="valid-id">PHP 0.00</div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">Official Receipt</label>
                    <div class="col-sm-6" id="official-receipt">PHP 0.00</div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">Transfer Fee</label>
                    <div class="col-sm-6" id="transfer-fee">PHP 0.00</div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">New Contract Fee</label>
                    <div class="col-sm-6" id="contract-fee">PHP 0.00</div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">Government Requirements</label>
                    <div class="col-sm-6" id="govt-requirements">PHP 0.00</div>
                </div>
                <div class="row mtl-25">
                    <label class="col-sm-6">Others</label>
                    <div class="col-sm-6" id="others">PHP 0.00</div>
                </div>

                <div class="row mtl-25">
                    <label class="col-sm-6">
                        <span style="margin-left: 50px">TOTAL SALES</span></label>
                    <div class="col-sm-6" id="total-sales">PHP 0.00</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" id="show-monthly-report-button" class="btn btn-primary">Generate Report</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<!-- PRINT RECEIPT -->
<div id="receipt-client" style="display: none">
    <div style="margin-top:30px; text-align: center">
        <h3>San Felipe Cemetery</h3>
        Official Receipt
    </div>
    <div style="margin-top:60px;">
        <table style="width: 100%" >
            <tbody>
            <tr>
                <td style="width:30%"></td>
                <td style="width:40%">Client's Name: <span id="print-name"></span></td>
                <td style="width:30%"></td>
            </tr>
            <tr style="height: 10px">
                <td style="width:30%"></td>
                <td style="width:40%"></td>
                <td style="width:30%"></td>
            </tr>
            <tr style="height: 50px">
                <td style="width:30%"></td>
                <td style="width:40%; text-align: center">
                    <div style="width: 50%;position: relative;float: left;">Category</div>
                    <div style="width: 50%;position: relative;float: left;">Amount</div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">Original Contract</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-original-contract"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">Valid ID</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-valid-id"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">Official Receipt</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-official-receipt"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">Transfer Fee</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-transfer-fee"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">New Contract Fee</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-contract-fee"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">Govt Requirements</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-govt-requirements"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative; float: left;">Others</div>
                    <div style="width: 50%;position: relative; text-align: right;float: left;">
                        PHP <span id="print-others"></span>
                    </div>
                </td>
                <td style="width:30%"></td>
            </tr>
            <tr style="height: 10px">
                <td style="width:30%"></td>
                <td style="width:40%"></td>
                <td style="width:30%"></td>
            </tr>
            <tr style="height: 50px">
                <td style="width:30%"></td>
                <td style="width:40%;">
                    <div style="width: 50%;position: relative;float: left;">Total Amount</div>
                    <div style="width: 50%;position: relative;float: left; text-align: right">PHP <span id="print-total-sales"></span></div>
                </td>
                <td style="width:30%"></td>
            </tr>
        </tbody>
    </table>

    </div>
</div>