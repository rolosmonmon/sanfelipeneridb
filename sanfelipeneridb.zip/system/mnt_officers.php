<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        List of Toda Officers
        <small>Maintenance</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Maintenance</li>
        <li class="active">List of Toda Officers</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <div class="row pull-right col-xs-4 p-b-15">
            <button type="button" id="officer_add" class="btn btn-block btn-default">
                Add Toda Officer
            </button>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <table id="view_officer" class="table table-bordered table-hover">
                            <thead>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Position</th>
                                <th>Toda Name</th>
                                <th>Plate No.</th>
                                <!-- <th>Status</th> -->
                                <th>Action</th>
                            </thead>
                            <tbody>
                                
                            </tbody>
                            <tfoot>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Position</th>
                                <th>Toda Name</th>
                                <th>Plate No.</th>
                                <!-- <th>Status</th> -->
                                <th>Action</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php include('common/footer.php'); ?>
<?php include('modal/maintenance/officer_modal.php'); ?>
<script type="text/javascript">
<?php include('common/js/officer.js'); ?>
</script>