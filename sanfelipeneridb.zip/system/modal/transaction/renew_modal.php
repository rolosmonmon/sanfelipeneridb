<!-- RENEW MEMBER -->
<div class="modal fade" id="modal-renew-member">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Contract Renewal</h4>
			</div>
			<div class="modal-body">
				<div class="center-text p-b-10">
					<h3>Verification</h3>
				</div>
				<div class="col-sm-3">
					<div class="row p-t-10">
						<div class="col-sm-9">
							Original Contract
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="renew-mem-regfee">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Valid I.D
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="renew-mem-regsticker">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Renewal Fee 
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="150" id="renew-mem-confirm">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Contract Renewal Fee
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="150" id="renew-mem-inspect">
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="row p-t-10">
						<div class="col-sm-9">
							Government Requirements
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="renew-mem-superv">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Official Receipt
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="renew-mem-farerate">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Photocopy of Old Contract
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="renew-mem-platesticker">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-3 m-t-5">
							Others
						</div>
						<div class="col-sm-9">
							<input type="text" class="form-control input-sm" placeholder="e.g. 150.00" id="renew-mem-others">
						</div>
					</div>
				</div>
				<div class="col-sm-5">
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Payment Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="renew-member-payment-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Effective Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="renew-member-effective-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Expiration Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="renew-member-expiration" disabled>
		                </div>
						</div>
					</div>
				</div>
				<div class="row">
					&nbsp;
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-renew-member" class="btn btn-primary pull-right">Save</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- RENEW TRICYCLE -->
<div class="modal fade" id="modal-renew-tricycle">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Renewal of Franchise</h4>
			</div>
			<div class="modal-body">
				<div class="center-text p-b-10">
					<h3>Order Payment</h3>
				</div>
				<div class="col-sm-2">
					&nbsp;
				</div>
				<div class="col-sm-3">
					<div class="row p-t-10">
						<div class="col-sm-9">
							MCH Franchise Permit P150
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="150" id="renew-tri-superv">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Petition P10
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="75" id="renew-tri-farerate">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-3 m-t-5">
							Others
						</div>
						<div class="col-sm-9">
							<input type="text" class="form-control input-sm" placeholder="e.g. 150.00" id="renew-tri-others">
						</div>
					</div>
				</div>
				<div class="col-sm-5">
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Payment Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="renew-tricycle-payment-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Effective Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="renew-tricycle-effective-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Expiration Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="renew-tricycle-expiration" disabled>
		                </div>
						</div>
					</div>
				</div>
				<div class="row">
					&nbsp;
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-renew-tricycle" class="btn btn-primary pull-right">Save</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>