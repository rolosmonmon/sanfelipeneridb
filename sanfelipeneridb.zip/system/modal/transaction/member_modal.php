<!-- ADD -->
<div class="modal fade" id="modal-add-member">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Add Member</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5">
						First Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-first-name" placeholder="e.g. Juan">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Middle Name
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-middle-name" placeholder="e.g. Dela">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Last Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-last-name" placeholder="e.g. Cruz">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Contact No. <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-contact" placeholder="e.g. 09123456789" >
						<small class="contact-validation c-red"></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Birthday <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="e.g. 01/01/1990" class="form-control pull-right" id="member-birthday">
		                </div>
		                <small></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Gender <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="member-gender">
		                    <option value="Male">Male</option>
		                    <option value="Female">Female</option>
		                </select>
                  </div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-add-member" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- EDIT -->
<div class="modal fade" id="modal-edit-member">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Edit Member</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5">
						First Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-edit-first-name" placeholder="e.g. Juan">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Middle Name
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-edit-middle-name" placeholder="e.g. Dela">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Last Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-edit-last-name" placeholder="e.g. Cruz">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Contact No. <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="member-edit-contact" placeholder="e.g. 09123456789">
						<small class="contact-validation c-red"></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Birthday <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="e.g. 01/01/1990" class="form-control pull-right" id="member-edit-birthday">
		                </div>
		                <small></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5">
						Gender <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="member-edit-gender">
		                    <option value="Male">Male</option>
		                    <option value="Female">Female</option>
		                </select>
                  </div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-edit-member" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>


<!-- DELETE -->
<div class="modal fade" id="modal-delete-member">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Delete Member</h4>
			</div>
			<div class="modal-body">
				Are you sure you want to delete this member?
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-delete-member" class="btn btn-primary">Delete</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- PENDING MEMBER -->
<div class="modal fade" id="modal-pending-member">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Pending</h4>
			</div>
			<div class="modal-body">
				<div class="center-text p-b-10">
					<h3>Verification</h3>
				</div>
				<div class="col-sm-3">
					<div class="row p-t-10">
						<div class="col-sm-9">
							Birth Certificate
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="1" id="reg-mem-regfee">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Death Certificate
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="1" id="reg-mem-regsticker">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Government Requirements
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="1" id="reg-mem-confirm">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Church Requirements
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="1" id="reg-mem-inspect">
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="row p-t-10">
						<div class="col-sm-9">
							Burial Fee 
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="1500" id="reg-mem-superv">
						</div>
					</div>
<!-- NAKA HIDE TO --> 
		<!-- <li class="hide">			 -->
			<div class="row p-t-10">
						<div class="col-sm-9">
							Contract 
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="2000" id="reg-mem-farerate">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Registration Fee
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="50" id="reg-mem-platesticker">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-3 m-t-5">
							Other Services
						</div>
						<div class="col-sm-9">
							<input type="text" class="form-control input-sm" placeholder="e.g. 150.00" id="reg-mem-others">
						</div>
					</div>
				</div>
		<!-- </li> -->
<!-- NAKA HIDE TO --> 		
				<div class="col-sm-5">
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Payment Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="member-payment-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Effective Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="member-effective-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-6 m-t-5 right-align">
							Expiration Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-6">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="member-expiration" disabled>
		                </div>
						</div>
					</div>
				</div>
				<div class="row">
					&nbsp;
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-pending-member" class="btn btn-primary pull-right">Save</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- HISTORY OF REGISTRATION -->
<div class="modal fade" id="modal-member-history">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Transaction History</h4>
			</div>
			<div class="modal-body">
				<div class="box">
                    <div class="box-body">
                        <table id="view_member_registration" class="table table-bordered table-hover">
                            <thead>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Payment Date</th>
                                <th>Effective Date</th>
                                <th>Expiration Date</th>
                                <th>Payment Amount</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                
                            </tbody>
                            <tfoot>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Payment Date</th>
                                <th>Effective Date</th>
                                <th>Expiration Date</th>
                                <th>Payment Amount</th>
                                <th>Action</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>