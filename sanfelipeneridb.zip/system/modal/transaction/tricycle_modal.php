<!-- ADD -->
<div class="modal fade" id="modal-add-tricycle">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Register Deceased</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Name of the Deceased <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-brand">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Number <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-motor-no">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Age Died <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-plate-no">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Cause of Death <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-chassis-no">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Type <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="tricycle-toda-name">
		                
		                </select>
                  </div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Client <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control select2" style="width: 100%" id="tricycle-member">
		                
		                </select>
                  </div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-add-tricycle" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- EDIT -->
<div class="modal fade" id="modal-edit-tricycle">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Edit Information</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Name of the Deceased <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-edit-brand">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Number <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-edit-motor-no">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Age Died <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-edit-plate-no">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Cause of Death <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="tricycle-edit-chassis-no">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Type <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="tricycle-edit-toda-name">
		                Lot Type
		                </select>
                  </div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Client <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" disabled id="tricycle-edit-member">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-edit-tricycle" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- DELETE -->
<div class="modal fade" id="modal-delete-tricycle">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Delete Tricycle</h4>
			</div>
			<div class="modal-body">
				Are you sure you want to delete this tricycle?
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-delete-tricycle" class="btn btn-primary">Delete</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- PENDING TRICYCLE -->
<!-- <div class="modal fade" id="modal-pending-tricycle">
</div> -->

<!-- HISTORY OF REGISTRATION -->
<div class="modal fade" id="modal-tricycle-history">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Transaction History</h4>
			</div>
			<div class="modal-body">
				<div class="box">
                    <div class="box-body">
                        <table id="view_tricycle_registration" class="table table-bordered table-hover">
                            <thead>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Payment Date</th>
                                <th>Effective Date</th>
                                <th>Expiration Date</th>
                                <th>Payment Amount</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                
                            </tbody>
                            <tfoot>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Payment Date</th>
                                <th>Effective Date</th>
                                <th>Expiration Date</th>
                                <th>Payment Amount</th>
                                <th>Action</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>