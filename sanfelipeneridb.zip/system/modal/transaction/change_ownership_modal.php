
<!-- CHANGE OWNERSHIP MODAL -->
<div class="modal fade" id="modal-change-ownership">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Transfer Contract</h4>
			</div>
			<div class="modal-body">
				<div class="center-text p-b-10">
					<h3>Verification</h3>
				</div>
				<div class="col-sm-4">
					<div class="row p-t-10">
						<div class="col-sm-9">
							Original Contract
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="ch-own-regfee">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Valid I.D
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="ch-own-mch">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Official Receipt 
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="" id="ch-own-petition">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Transfer Fee
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="150" id="ch-own-confirm">
						</div>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="row p-t-10">
						<div class="col-sm-9">
							New Contract Fee
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="150" id="ch-own-inspect">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-9">
							Government Requirements 
						</div>
						<div class="col-sm-2 m-l-5">
							<input type="checkbox" class="flat-green" value="40" id="ch-own-superv">
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-3 m-t-5">
							Others
						</div>
						<div class="col-sm-9">
							<input type="text" class="form-control input-sm" placeholder="e.g. 150.00" id="ch-own-others">
						</div>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="row p-t-10">
						<div class="col-sm-4 right-align">
							Payment Date <span class="c-red">*</span>
						</div>
						<div class="col-sm-8">
							<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="" class="form-control pull-right" id="ch-own-payment-date">
		                </div>
						</div>
					</div>
					<div class="row p-t-10">
						<div class="col-sm-4 m-t-5 right-align">
							New Companied by <span class="c-red">*</span>
						</div>
						<div class="col-sm-8">
							<select class="form-control" id="ch-own-member">
			                
			                </select>
	                  	</div>
	                 </div>
				</div>
				<div class="row">
					&nbsp;
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-change-ownership" class="btn btn-primary pull-right">Save</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>


<!-- SEE HISTORY MODAL -->
<div class="modal fade" id="modal-see-history">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">History of Owners</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="box">
	                    <div class="box-body p-10">
	                        <table id="view_history" class="table table-bordered table-hover">
	                            <thead>
	                                <th>From</th>
	                                <th>To</th>
	                                <th>Payment Date</th>
	                                <th>Action</th>
	                            </thead>
	                            <tbody>
	                                
	                            </tbody>
	                            <tfoot>
	                                <th>From</th>
	                                <th>To</th>
	                                <th>Payment Date</th>
	                                <th>Action</th>
	                            </tfoot>
	                        </table>
	                    </div>
	                </div>
				</div>
				<div class="row">
					&nbsp;
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-change-ownership" class="btn btn-primary pull-right">Save</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>