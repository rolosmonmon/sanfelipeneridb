<!-- ADD -->
<div class="modal fade" id="modal-add-officer">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Register Toda Officer</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Member <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control select2" style="width: 100%" id="officer-member">
		                
		                </select>
                  </div>
				</div>
				<div class="row m-t-10">
					<div class="col-sm-5 m-t-5 right-align">
						Position <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="officer-position">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-add-officer" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- EDIT -->
<div class="modal fade" id="modal-edit-officer">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Register Toda Officer</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Member <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control select2" style="width: 100%" id="officer-edit-member">
		                
		                </select>
                  </div>
				</div>
				<div class="row m-t-10">
					<div class="col-sm-5 m-t-5 right-align">
						Position <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="officer-edit-position">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-edit-officer" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- DELETE -->
<div class="modal fade" id="modal-delete-officer">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Delete Toda Officer</h4>
			</div>
			<div class="modal-body">
				Are you sure you want to delete this toda officer?
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-delete-officer" class="btn btn-primary">Delete</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>