<!-- ADD -->
<div class="modal fade" id="modal-add-toda">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Add Lot Type</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Type <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="toda-toda-name" placeholder="e.g. SM Toda">
					</div>
				</div>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Color <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="color" id="toda-toda-color" value="#00000">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-add-toda" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- EDIT -->
<div class="modal fade" id="modal-edit-toda">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Edit Lot Name</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="toda-edit-toda-name" placeholder="e.g. SM Toda">
					</div>
				</div>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Lot Color <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="color" id="toda-edit-toda-color" value="#00000">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-edit-toda" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>


<!-- DELETE -->
<div class="modal fade" id="modal-delete-toda">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Delete Lot</h4>
			</div>
			<div class="modal-body">
				Are you sure you want to delete this toda?
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-delete-toda" class="btn btn-primary">Delete</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>