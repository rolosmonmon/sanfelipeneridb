<!-- ADD -->
<div class="modal fade" id="modal-add-user">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Add User Admin</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						First Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-first-name" placeholder="e.g. Juan">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Middle Name
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-middle-name" placeholder="e.g. Dela">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Last Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-last-name" placeholder="e.g. Cruz">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Contact No. <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-contact" placeholder="e.g. 09123456789">
						<small class="contact-validation c-red"></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Birthday <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="e.g. 01/01/1990" class="form-control pull-right" id="user-birthday">
		                </div>
		                	<small></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Gender <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="user-gender">
		                    <option value="Male">Male</option>
		                    <option value="Female">Female</option>
		                </select>
                  </div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Position <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="user-position">
		                    <option value="Officer in Charge">Officer-In-Charge</option>
		                    <option value="Administrator">Administrator</option>
		                </select>
		            </div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Password <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="password" id="user-password">
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-add-user" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>

<!-- EDIT -->
<div class="modal fade" id="modal-edit-user">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Edit User Admin</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						First Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-edit-first-name" placeholder="e.g. Juan">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Middle Name
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-edit-middle-name" placeholder="e.g. Dela">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Last Name <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-edit-last-name" placeholder="e.g. Cruz">
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Contact No. <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<input class="form-control" type="text" id="user-edit-contact" placeholder="e.g. 09123456789">
						<small class="contact-validation c-red"></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Birthday <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<div class="input-group date">
		                	<div class="input-group-addon">
		                		<i class="fa fa-calendar"></i>
		                	</div>
		                	<input type="text" placeholder="e.g. 01/01/1990" class="form-control pull-right" id="user-edit-birthday">
		                </div>
		                <small></small>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Gender <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="user-edit-gender">
		                    <option value="Male">Male</option>
		                    <option value="Female">Female</option>
		                </select>
                  </div>
				</div>
				<div class="row">
					<div class="col-sm-5 m-t-5 right-align">
						Position <span class="c-red">*</span>
					</div>
					<div class="col-sm-5 m-l-5">
						<select class="form-control" id="user-edit-position">
		                    <option value="Chief Officer">Officer-In-Charge</option>
		                    <option value="Assistant Chief">Administrator</option>
		                </select>
		            </div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-edit-user" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>


<!-- DELETE -->
<div class="modal fade" id="modal-delete-user">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Delete User Admin</h4>
			</div>
			<div class="modal-body">
				Are you sure you want to delete this user?
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="button" id="save-delete-user" class="btn btn-primary">Delete</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>