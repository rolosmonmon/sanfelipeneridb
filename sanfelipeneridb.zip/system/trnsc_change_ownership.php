<?php include('common/header.php'); ?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Transfer Contract
        <small>Transaction</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li>Transaction</li>
        <li class="active">Transfer Contract</li>
      </ol>
    </section>

    <!-- TABLE -->
    <section class="content">
        <!-- <div class="row pull-right col-xs-4 p-b-15">
            <button type="button" id="tricycle_add" class="btn btn-block btn-default">
                Register Tricycle
            </button>
        </div> -->
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <table id="view_all_tricycle" class="table table-bordered table-hover">
                            <thead>
                                <th>Name of the Deceased</th>
                                <th>Lot Number</th>
                                <th>Age Died</th>
                                <th>Cause of Death</th>
                                <th>Lot Type</th>
                                <th>Client</th>
                                <!-- <th>Status</th> -->
                                <th>Action</th>
                            </thead>
                            <tbody>
                                
                            </tbody>
                           <!--  <tfoot>
                                <th>Brand</th>
                                <th>Plate No</th>
                                <th>Motor No</th>
                                <th>Chassis No</th>
                                <th>Toda Name</th>
                                <th>Member/Driver</th>
                                <! <th>Status</th> -->
                                <!-- <th>Action</th> -->
                            <!-- </tfoot> --> 
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php include('common/footer.php'); ?>
<?php include('modal/transaction/change_ownership_modal.php'); ?>
<script type="text/javascript">
<?php include('common/js/change_ownership.js'); ?>
</script>