<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

$month = date("m/d/Y", strtotime("-1 months"));

if($action == 'view_users'){

	$stmt = $db->prepare('SELECT * FROM user_admin 
		WHERE status = 1 AND date_created >= ?');

	$stmt->bindParam(1, $month);
	$stmt->execute();

	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']; ?></td>
			<td><?php echo $row['position'] ?></td>
		</tr>
		<?php
	}

} else if($action == 'view_members'){
	$stmt = $db->prepare('SELECT * FROM member
		WHERE status = 1 AND date_created >= ?');

	$stmt->bindParam(1, $month);
	$stmt->execute();

	while($row = $stmt->fetch()){
		if($row['member_status'] == 'Pending'){
			$btn = 'warning';
		} else if($row['member_status'] == 'Active'){
			$btn = 'success';
		} else if($row['member_status'] == 'Inactive'){
			$btn = 'danger';
		} 

		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']; ?></td>
			<td><button class="btn btn-xs btn-<?php echo $btn; ?>"> <?php echo $row['member_status'] ?>
				</button></td>
		</tr>
		<?php
	}
} else if($action == 'sms_functions'){

	$data_sms = array();
	$date_today = date('m-d-Y');
	$member_priority = array();
	$member_not_priority = array();
	$member_not_priority_not_sent = array();

	$list_api = ['TR-JOSHU736724_SUNN9', 'TR-PAULI762510_28EDU', 'TR-LALAI080415_B9KFL', 'TR-AUSTI151161_17QP', 'TR-DIANA921473_TN1IG'];
	foreach ($list_api as $key => $value) {
		$api_count[$value] = 0;
	}
	###########################
	##	QUERY TEXT FOR TODAY ##
	###########################
	$stmt = $db->prepare('SELECT COUNT(*) as count, api_code  FROM sms_table 
		WHERE status = 1 AND sms_date = ? GROUP BY api_code');
	$day = (((int) date('d') - 1) < 10) ? '0'.((int) date('d') - 1) : (int) date('d') - 1;
	$date_now = date('m/').$day.date('/Y');

	$stmt->bindParam(1, $date_now);
	$stmt->execute();
	while ($row = $stmt->fetch()) {
		$api_count[$row['api_code']] = $row['count'];
	}

	### !!! PRIORITY !!! ###
		$message_today = 'Ka-Toda, ngayon ang expiration ng rehistro mo. Rehistro na ulit. From: Transport Regulatory Board.';

		$date_now = date('Y-m-d'); //echo $date_now;
		$stmt = $db->prepare("SELECT * FROM member_registration mr JOIN member m
			ON mr.member_id = m.member_id
			WHERE texted = 0 AND CONCAT(SUBSTRING(expiration, 7),'-',SUBSTRING(expiration, 1, 2),'-',SUBSTRING(expiration, 4, 2)) = ?");
		$stmt->bindParam(1, $date_now);
		$stmt->execute();

		$count1 = 0;
		while($row = $stmt->fetch()){
			$dataP[] = array('contact' => $row['contact'], 'expiration' => $row['expiration'], 'memreg_id' => $row['memreg_id']);
		}
		// print_r($dataP);
		if(isset($dataP)){	
			foreach ($dataP as $key => $value) {
				$data_sms_memberP[] = array(
					'contact' => $value['contact'],
					'transaction' => 'Expiration Now - Member',
					'expiration' => $value['expiration'],
					'memreg_id' => $value['memreg_id']
				);
				$count1++;
			}
		}

	// // 1 DAY EXPIRATION
			$message_after = 'Ka-Toda, expired na ang iyong rehistro. Rehistro ka na ulit. From: Transport Regulatory Board.';

			$date_now = date('Y-m-d');
			$stmt = $db->prepare("SELECT * FROM member_registration mr JOIN member m
				ON mr.member_id = m.member_id
				WHERE texted = 0 AND CONCAT(SUBSTRING(expiration, 7),'-',SUBSTRING(expiration, 1, 2),'-',SUBSTRING(expiration, 4, 2)) < ?");
			$stmt->bindParam(1, $date_now);
			$stmt->execute();

			while($row = $stmt->fetch()){
				$data3[] = array('contact' => $row['contact'], 'expiration' => $row['expiration'], 'memreg_id' => $row['memreg_id']);
			}

			if(isset($data3)){	
				foreach ($data3 as $key => $value) {
					$data_sms_member[] = array(
						'contact' => $value['contact'],
						'transaction' => 'Expiration After - Member',
						'expiration' => $value['expiration'],
						'memreg_id' => $value['memreg_id']
					);
					$count1++;
				}
			}

	// // THIS IS FOR 5 DAYS EXPIRATION
			$message_5days = 'Paexpire na ang iyong rehistro, magparehistro ka na ulit ka-Toda! From: Transport Regulatory Board.';

			$date_less5 = date_create(date('Y-m-d'));
			date_sub($date_less5, date_interval_create_from_date_string('5 days'));
			$less5days = date_format($date_less5, 'Y-m-d');

			$stmt = $db->prepare("SELECT * FROM member_registration mr JOIN member m
				ON mr.member_id = m.member_id
				WHERE CONCAT(SUBSTRING(expiration, 7),'-',SUBSTRING(expiration, 1, 2),'-',SUBSTRING(expiration, 4, 2)) BETWEEN ? AND ?");
			$stmt->bindParam(1, $less5days);
			$stmt->bindParam(2, date('Y-m-d'));
			$stmt->execute();

			while($row = $stmt->fetch()){
				$data3[] = array('contact' => $row['contact'], 'expiration' => $row['expiration'], 'memreg_id' => $row['memreg_id']);
			}

			if(isset($data3)){	
				foreach ($data3 as $key => $value) {
					$data_sms_member[] = array(
						'contact' => $value['contact'],
						'transaction' => 'Expiration After - Member',
						'expiration' => $value['expiration'],
						'memreg_id' => $value['memreg_id']
					);
					$count1++;
				}
			}

	// PRIORITY FIRST
	// ARRANGE IF TO TEXT TODAY
		if(isset($data_sms_memberP)){
			$count_text = 0;
			foreach ($data_sms_memberP as $key => $value) {
				$limit = 10-$api_count['TR-LALAI080415_B9KFL'];

				// THIS IS FOR PEOPLE TO TEXT
				if($count_text <= $limit){
					$member_priority[] = array(
						'sms_date' => date('m/d/Y'),
						'api_code' => 'TR-LALAI080415_B9KFL',
						'transaction' => $value['transaction'],
						'texted' => 1,
						'expiration' => $value['expiration'],
						'contact' => $value['contact'],
						'memreg_id' => $value['memreg_id']
						);
					
				}

				$count_text++;
			}
		}

	// NOT PRIORITY 
	// ARRANGE IF TO TEXT TODAY
		if(isset($data_sms_member)){
			$count_text = 0;
			foreach ($data_sms_member as $key => $value) {
				$limit = 10-$api_count['TR-PAULI762510_28EDU'];

				// THIS IS FOR PEOPLE TO TEXT
				if($count_text <= $limit){
					$member_not_priority[] = array(
						'sms_date' => date('m/d/Y'),
						'api_code' => 'TR-PAULI762510_28EDU',
						'transaction' => $value['transaction'],
						'texted' => 1,
						'expiration' => $value['expiration'],
						'contact' => $value['contact'],
						'memreg_id' => $value['memreg_id']
						);
					
				} else {
					$member_not_priority_not_sent[] = array(
						'sms_date' => '',
						'api_code' => 'TR-PAULI762510_28EDU',
						'transaction' => $value['transaction'],
						'texted' => 0,
						'expiration' => $value['expiration'],
						'contact' => $value['contact'],
						'memreg_id' => $value['memreg_id']
						);
				}

				$count_text++;
			}
		}
	
	// print_r($member_priority);exit;
	// TEXT THEM NOW !!!
		// PRIORITY MEMBER SENT
			if(!empty($member_priority)){	
				foreach ($member_priority as $key => $value) {

					// INSERT DATA
					$stmt = $db->prepare("INSERT INTO sms_table (api_code, sms_date, transaction, texted, expiration, contact, date_created, created_by, status) VALUES (?,?,?,?,?,?,?,?,?)");
					$default_created = 1;
					$stat = 1;
					$texted = 1;
					$stmt->bindParam(1, $value['api_code']);
					$stmt->bindParam(2, $value['sms_date']);
					$stmt->bindParam(3, $value['transaction']);
					$stmt->bindParam(4, $texted);
					$stmt->bindParam(5, $value['expiration']);
					$stmt->bindParam(6, $value['contact']);
					$stmt->bindParam(7, date("Y-m-d H:i:s"));
					$stmt->bindParam(8, $default_created);
					$stmt->bindParam(9, $stat);
					$stmt->execute();

					// UPDATE MEMBER REGISTRATION TO TEXTED
					$stmt1 = $db->prepare("UPDATE member_registration SET texted=? WHERE memreg_id=?");
		
					$stmt1->bindParam(1, $texted);
					$stmt1->bindParam(2, $value['memreg_id']);
					$stmt1->execute();
					// print_r($value);exit;
					// THIS IS THE TEXT
					$result = itexmo($value['contact'], $message_today, $value['api_code']);

					if ($result == ""){
						echo "iTexMo: No response from server!!!
						Please check the METHOD used (CURL or CURL-LESS). If you are using CURL then try CURL-LESS and vice versa.	
						Please CONTACT US for help. ";	
					} else if ($result == 0){
						echo "Welcome to Dashboard!";
					} else{	
						echo "Error Num ". $result . " was encountered!";
					}
				}
				// print_r('Welcome to Dashboard');
			} else {
				echo 'empty';
			}
		// // NOT PRIORITY MEMBER SENT
		// 	// print_r(count($member_not_priority));exit;
		// 	if(isset($member_not_priority)){	
		// 		foreach ($member_not_priority as $key => $value) {
		// 			$value['api_code'] = 'TR-JOSHU736724_SUNN9';
		// 			// INSERT DATA
		// 			$stmt = $db->prepare("INSERT INTO sms_table (api_code, sms_date, transaction, texted, expiration, contact, date_created, created_by, status) VALUES (?,?,?,?,?,?,?,?,?)");
		// 			$default_created = 1;
		// 			$stat = 1;
		// 			$texted = 1;
		// 			$stmt->bindParam(1, $value['api_code']);
		// 			$stmt->bindParam(2, $value['sms_date']);
		// 			$stmt->bindParam(3, $value['transaction']);
		// 			$stmt->bindParam(4, $texted);
		// 			$stmt->bindParam(5, $value['expiration']);
		// 			$stmt->bindParam(6, $value['contact']);
		// 			$stmt->bindParam(7, date("Y-m-d H:i:s"));
		// 			$stmt->bindParam(8, $default_created);
		// 			$stmt->bindParam(9, $stat);
		// 			$stmt->execute();

		// 			// UPDATE MEMBER REGISTRATION TO TEXTED
		// 			$stmt1 = $db->prepare("UPDATE member_registration SET texted=? WHERE memreg_id=?");
		
		// 			$stmt1->bindParam(1, $texted);
		// 			$stmt1->bindParam(2, $value['memreg_id']);
		// 			$stmt1->execute();

		// 			$m = ($value['transaction'] = 'Expiration After - Member') ? $message_after : $message_after ;
		// 			// THIS IS THE TEXT
		// 			// $result = itexmo($value['contact'], $m, $value['api_code']);

		// 			// print_r($result);
		// 		}
		// 	}

		// // NOT PRIORITY MEMBER NOT SENT
		// 	if(isset($member_not_priority_not_sent){	
		// 		foreach ($member_not_priority_not_sent as $key => $value) {
		// 			// INSERT DATA
		// 			$stmt = $db->prepare("INSERT INTO sms_table (api_code, sms_date, transaction, texted, expiration, contact, date_created, created_by, status) VALUES (?,?,?,?,?,?,?,?,?)");
		// 			$default_created = 1;
		// 			$stat = 1;
		// 			$texted = 1;
		// 			$stmt->bindParam(1, $value['api_code']);
		// 			$stmt->bindParam(2, $value['sms_date']);
		// 			$stmt->bindParam(3, $value['transaction']);
		// 			$stmt->bindParam(4, $texted);
		// 			$stmt->bindParam(5, $value['expiration']);
		// 			$stmt->bindParam(6, $value['contact']);
		// 			$stmt->bindParam(7, date("Y-m-d H:i:s"));
		// 			$stmt->bindParam(8, $default_created);
		// 			$stmt->bindParam(9, $stat);
		// 			$stmt->execute();

		// 		}
		// 	}
	// print_r($member_not_priority);
}

function itexmo($number,$message,$apicode){
	$ch = curl_init();
	$itexmo = array('1' => $number, '2' => $message, '3' => 'TR-AUSTI151161_17QP');
	curl_setopt($ch, CURLOPT_URL,"https://www.itexmo.com/php_api/api.php");
	curl_setopt($ch, CURLOPT_POST, 1);
	 curl_setopt($ch, CURLOPT_POSTFIELDS, 
	          http_build_query($itexmo));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	return curl_exec ($ch);
	curl_close ($ch);
}
?>

