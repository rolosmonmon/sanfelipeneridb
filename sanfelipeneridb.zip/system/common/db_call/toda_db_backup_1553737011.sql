

CREATE TABLE `archive` (
  `archive_id` int(6) NOT NULL AUTO_INCREMENT,
  `id` int(6) DEFAULT NULL,
  `table_name` varchar(30) DEFAULT NULL,
  `deleted_by` int(6) DEFAULT NULL,
  `restored_by` int(6) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`archive_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO archive VALUES("1","3","toda_name","1","","2019-03-26 17:43:53","1");



CREATE TABLE `change_ownership` (
  `change_id` int(6) NOT NULL AUTO_INCREMENT,
  `member_id_from` int(6) DEFAULT NULL,
  `member_id_to` int(6) DEFAULT NULL,
  `regfee` varchar(30) DEFAULT NULL,
  `mch` varchar(30) DEFAULT NULL,
  `petition` varchar(30) DEFAULT NULL,
  `confirm` varchar(30) DEFAULT NULL,
  `inspect` varchar(30) DEFAULT NULL,
  `superv` varchar(30) DEFAULT NULL,
  `others` varchar(30) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL,
  `payment_date` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`change_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO change_ownership VALUES("1","2","4","","","","150","150","40","150.00","490","03/17/2019","2019-03-19 03:52:54","1","1");
INSERT INTO change_ownership VALUES("2","1","3","","","","150","150","40","120.00","460","03/19/2019","2019-03-19 04:24:37","1","1");
INSERT INTO change_ownership VALUES("3","3","4","","","","150","150","40","600.00","940","03/19/2019","2019-03-19 03:35:04","1","1");
INSERT INTO change_ownership VALUES("4","4","5","","","","150","150","40","1000.00","1340","03/19/2019","2019-03-19 03:35:45","1","1");
INSERT INTO change_ownership VALUES("5","6","8","","","","150","150","40","5000.00","5340","03/19/2019","2019-03-19 03:41:25","1","1");
INSERT INTO change_ownership VALUES("6","8","9","","","","150","150","40","6000.00","6340","03/20/2019","2019-03-19 03:42:03","1","1");
INSERT INTO change_ownership VALUES("7","9","10","","","","150","150","40","10000.00","10340","04/01/2019","2019-03-19 03:42:50","1","1");
INSERT INTO change_ownership VALUES("8","5","7","","","","150","150","40","500.00","840","03/19/2019","2019-03-19 03:48:34","1","1");
INSERT INTO change_ownership VALUES("9","7","10","","","","150","150","40","500.00","840","03/20/2019","2019-03-20 04:52:35","1","1");
INSERT INTO change_ownership VALUES("10","14","16","","","","150","150","40","500.00","840","03/26/2019","2019-03-26 21:48:14","1","1");
INSERT INTO change_ownership VALUES("11","17","19","","","","150","150","40","15000","15340","03/26/2019","2019-03-26 22:10:48","1","1");



CREATE TABLE `enforcer` (
  `enforcer_id` int(6) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `birthday` varchar(15) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`enforcer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




CREATE TABLE `member` (
  `member_id` int(6) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `birthday` varchar(15) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `member_status` varchar(15) DEFAULT NULL,
  `memreg_id` int(6) DEFAULT NULL,
  `availability` varchar(10) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO member VALUES("1","Juan","Dela","Cruz","09053155057","03/01/1997","Male","Inactive","1","no","2019-03-01 20:07:22","1","0");
INSERT INTO member VALUES("2","Charlene","","Santiago","09031243532","07/17/1997","Female","Inactive","2","no","2019-03-01 19:57:52","1","0");
INSERT INTO member VALUES("3","Cha","","Santiago","21312332036","07/17/1997","Female","Inactive","3","no","2019-03-19 04:18:15","1","0");
INSERT INTO member VALUES("4","Jonathan","","Rivera","09123124124","03/25/1997","Male","Active","13","no","2019-03-19 04:23:21","1","0");
INSERT INTO member VALUES("5","Alex","","III","10301312042","04/11/1997","Male","Inactive","9","no","2019-03-19 04:13:33","1","0");
INSERT INTO member VALUES("6","Shareteaa","","Milktea","09021412534","08/01/1996","Male","Inactive","10","no","2019-03-19 04:16:15","1","0");
INSERT INTO member VALUES("7","Edgar","","Poe","01931234124","04/04/1997","Male","Inactive","12","no","2019-03-19 04:21:44","1","0");
INSERT INTO member VALUES("8","Ash","","Sales","10293124223","02/27/1987","Male","Inactive","11","no","2019-03-19 03:32:53","1","0");
INSERT INTO member VALUES("9","Erika","","Gonza","09124252323","03/20/1998","Female","Inactive","14","no","2019-03-19 03:42:32","1","0");
INSERT INTO member VALUES("10","ASH","","TABA","09124125232","02/26/1998","Male","Active","15","yes","2019-03-19 03:36:19","1","0");
INSERT INTO member VALUES("11","TeaTap","","Wilson","09124152334","02/24/1997","Male","Pending","16","","2019-03-19 03:39:41","1","0");
INSERT INTO member VALUES("12","TEA","","TEA","23235235235","01/01/1990","Male","Active","24","yes","2019-03-19 03:35:03","1","0");
INSERT INTO member VALUES("13","Juan","Dela","Cruz","09287387637","02/13/1990","Male","Active","18","yes","2019-03-20 05:45:00","1","0");
INSERT INTO member VALUES("14","Rafael","Dela Cruz","Lim","09128376783","11/21/1971","Male","Inactive","19","no","2019-03-20 05:19:42","1","1");
INSERT INTO member VALUES("15","Gemma","","Cruz","01212322366","02/27/1990","Female","Active","21","no","2019-03-26 17:20:04","1","1");
INSERT INTO member VALUES("16","Emma","","Go","91241212503","03/07/1997","Female","Active","22","no","2019-03-26 21:47:25","1","1");
INSERT INTO member VALUES("17","Jonas","","Dela Cruz","09124536756","03/20/1996","Male","Inactive","23","no","2019-03-26 22:01:39","1","1");
INSERT INTO member VALUES("18","Joe","","Jonas","09122353455","03/04/1996","Male","Active","26","no","2019-03-26 22:05:27","1","1");
INSERT INTO member VALUES("19","Emannuel","","Stone","09124233212","03/06/1996","Female","Active","27","no","2019-03-26 22:07:13","1","1");



CREATE TABLE `member_registration` (
  `memreg_id` int(6) NOT NULL AUTO_INCREMENT,
  `member_id` int(6) DEFAULT NULL,
  `regfee` varchar(30) DEFAULT NULL,
  `regsticker` varchar(30) DEFAULT NULL,
  `confirm` varchar(30) DEFAULT NULL,
  `inspect` varchar(30) DEFAULT NULL,
  `superv` varchar(30) DEFAULT NULL,
  `farerate` varchar(30) DEFAULT NULL,
  `platesticker` varchar(30) DEFAULT NULL,
  `others` varchar(30) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL,
  `payment_date` varchar(30) DEFAULT NULL,
  `effective_date` varchar(30) DEFAULT NULL,
  `expiration` varchar(30) DEFAULT NULL,
  `registration_status` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`memreg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO member_registration VALUES("1","1","1","1","1","1","1500","2000","50","150.00","3704","03/15/2019","03/17/2019","03/15/2020","Active","2019-03-01 20:07:22","1","1");
INSERT INTO member_registration VALUES("2","2","1","1","1","1","1500","2000","50","150.00","3704","03/17/2019","03/19/2019","03/17/2020","Active","2019-03-01 19:57:52","1","1");
INSERT INTO member_registration VALUES("3","3","1","1","1","1","1500","2000","50","150.00","3704","03/17/2017","03/21/2017","03/19/2018","Active","2019-03-19 04:18:15","1","1");
INSERT INTO member_registration VALUES("4","4","1","1","1","1","1500","2000","50","150.00","3704","03/19/2018","03/21/2018","03/19/2019","Inactive","2019-03-19 04:23:21","1","1");
INSERT INTO member_registration VALUES("5","5","1","1","1","1","1500","2000","50","500.00","4054","03/17/2017","03/19/2018","03/17/2019","Inactive","2019-03-19 04:13:33","1","1");
INSERT INTO member_registration VALUES("6","6","1","1","1","1","1500","2000","50","900.00","4454","03/19/2018","03/21/2018","03/19/2019","Inactive","2019-03-19 04:16:15","1","1");
INSERT INTO member_registration VALUES("7","5","","","150","150","","","","5000.00","5300","03/19/2018","03/21/2018","03/19/2019","Inactive","2019-03-19 04:20:30","1","1");
INSERT INTO member_registration VALUES("8","7","1","1","1","1","1500","2000","50","1050.00","4604","03/19/2018","03/21/2018","03/19/2019","Inactive","2019-03-19 04:21:44","1","1");
INSERT INTO member_registration VALUES("9","5","","","150","150","","","","5000","5300","03/19/2019","03/21/2019","03/19/2020","Active","2019-03-19 03:42:53","1","1");
INSERT INTO member_registration VALUES("10","6","","","150","150","","","","5000.00","5300","04/01/2019","04/01/2019","03/30/2020","Active","2019-03-19 04:31:07","1","1");
INSERT INTO member_registration VALUES("11","8","1","1","1","1","1500","2000","50","6000.00","9554","03/19/2019","03/21/2019","03/19/2020","Active","2019-03-19 03:32:53","1","1");
INSERT INTO member_registration VALUES("12","7","","","150","150","","","","1500.00","1800","03/19/2019","03/21/2019","03/19/2020","Active","2019-03-19 03:34:19","1","1");
INSERT INTO member_registration VALUES("13","4","","","150","150","","","","600.00","900","03/19/2019","03/19/2019","03/17/2020","Active","2019-03-19 03:41:38","1","1");
INSERT INTO member_registration VALUES("14","9","1","1","1","1","1500","2000","50","5000.00","8554","03/19/2018","04/03/2019","04/01/2020","Active","2019-03-19 03:42:32","1","1");
INSERT INTO member_registration VALUES("15","10","1","1","1","1","1500","2000","50","8000.00","11554","03/19/2019","03/21/2019","03/19/2020","Active","2019-03-19 03:36:19","1","1");
INSERT INTO member_registration VALUES("16","11","","","","","","","","","","","","","Active","2019-03-19 03:39:42","1","1");
INSERT INTO member_registration VALUES("17","12","1","1","1","1","1500","2000","50","150.00","3704","03/19/2018","03/19/2018","03/17/2019","Inactive","2019-03-19 03:35:03","1","1");
INSERT INTO member_registration VALUES("18","13","1","1","1","1","1500","2000","50","150.00","3704","03/20/2019","03/21/2019","03/19/2020","Active","2019-03-20 05:45:00","1","1");
INSERT INTO member_registration VALUES("19","14","1","1","1","1","1500","2000","50","150.00","3704","03/23/2019","03/30/2019","03/28/2020","Active","2019-03-20 05:19:42","1","1");
INSERT INTO member_registration VALUES("20","15","1","1","1","1","1500","2000","50","500.00","4054","03/26/2018","03/28/2018","03/26/2019","Inactive","2019-03-26 17:20:04","1","1");
INSERT INTO member_registration VALUES("21","15","","","150","150","","","","500.00","800","03/26/2019","03/27/2019","03/25/2020","Active","2019-03-26 21:46:33","1","1");
INSERT INTO member_registration VALUES("22","16","1","1","1","1","1500","2000","50","600.00","4154","03/26/2019","03/26/2019","03/24/2020","Active","2019-03-26 21:47:25","1","1");
INSERT INTO member_registration VALUES("23","17","1","1","1","1","1500","2000","50","150.00","3704","03/26/2019","03/28/2019","03/26/2020","Active","2019-03-26 22:01:39","1","1");
INSERT INTO member_registration VALUES("24","12","","","150","150","","","","10000","10300","03/26/2019","03/28/2019","03/26/2020","Active","2019-03-26 22:03:32","1","1");
INSERT INTO member_registration VALUES("25","18","1","1","1","1","1500","2000","50","150.00","3704","03/26/2018","03/28/2018","03/26/2019","Inactive","2019-03-26 22:05:27","1","1");
INSERT INTO member_registration VALUES("26","18","","","150","150","","","","150.00","450","03/26/2019","03/28/2019","03/26/2020","Active","2019-03-26 22:06:19","1","1");
INSERT INTO member_registration VALUES("27","19","1","1","1","1","1500","2000","50","250.00","3804","03/26/2019","03/28/2019","03/26/2020","Active","2019-03-26 22:07:13","1","1");



CREATE TABLE `sms_table` (
  `sms_id` int(6) NOT NULL AUTO_INCREMENT,
  `api_code` varchar(30) DEFAULT NULL,
  `sms_date` varchar(30) DEFAULT NULL,
  `transaction` varchar(30) DEFAULT NULL,
  `texted` int(2) DEFAULT NULL,
  `expiration` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`sms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




CREATE TABLE `toda_name` (
  `toda_id` int(6) NOT NULL AUTO_INCREMENT,
  `toda_name` varchar(30) DEFAULT NULL,
  `toda_color` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`toda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO toda_name VALUES("1","Apartment","#00ff00","2019-03-01 20:11:31","1","1");
INSERT INTO toda_name VALUES("2","Niche","#ff1a00","2019-03-01 20:11:56","1","1");
INSERT INTO toda_name VALUES("3","Mauseleum","#000000","2019-03-19 03:41:04","1","0");
INSERT INTO toda_name VALUES("4","Urn","#000000","2019-03-26 17:45:10","1","1");



CREATE TABLE `toda_officer` (
  `officer_id` int(6) NOT NULL AUTO_INCREMENT,
  `tricycle_id` int(6) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`officer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




CREATE TABLE `tricycle` (
  `tricycle_id` int(6) NOT NULL AUTO_INCREMENT,
  `trireg_id` int(6) DEFAULT NULL,
  `chassis_no` varchar(30) DEFAULT NULL,
  `plate_no` varchar(30) DEFAULT NULL,
  `brand` varchar(30) DEFAULT NULL,
  `motor_no` varchar(30) DEFAULT NULL,
  `member_id` int(6) DEFAULT NULL,
  `toda_id` int(6) DEFAULT NULL,
  `tricycle_status` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`tricycle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO tricycle VALUES("1","1","Heart Attack","20","Rafael Lim","1","1","1","Pending","2019-03-01 20:12:44","1","0");
INSERT INTO tricycle VALUES("2","2","Cardiac Arrest","65","Rafael","1","1","2","Pending","2019-03-01 19:56:36","1","0");
INSERT INTO tricycle VALUES("3","3","Heart Attack","90","Diana","1","4","1","Pending","2019-03-19 04:18:36","1","0");
INSERT INTO tricycle VALUES("4","4","Heart Attack","90","Pau","2","3","1","Pending","2019-03-19 04:20:33","1","0");
INSERT INTO tricycle VALUES("5","5","Hepa","90","Tiago","3","5","1","Pending","2019-03-19 04:22:11","1","0");
INSERT INTO tricycle VALUES("6","6","Obesity","86","PAT STAR","5","7","1","Pending","2019-03-19 03:37:19","1","0");
INSERT INTO tricycle VALUES("7","7","Milktea","90","ChaChago","6","10","2","Pending","2019-03-19 03:39:11","1","0");
INSERT INTO tricycle VALUES("8","8","Hepa","90","asf","6","10","1","Pending","2019-03-19 03:41:17","1","0");
INSERT INTO tricycle VALUES("9","9","katamaran","21","Rafael Lim","4","10","1","Pending","2019-03-20 05:00:07","1","0");
INSERT INTO tricycle VALUES("10","10","Cardiac Arrest","78","Diana Tolin","1","16","1","Pending","2019-03-20 05:36:30","1","1");
INSERT INTO tricycle VALUES("11","11","Obesity","Cruz","Mark","5","15","1","Pending","2019-03-26 17:22:26","1","1");
INSERT INTO tricycle VALUES("12","12","Obesity","45","Cha","6","19","1","Pending","2019-03-26 22:02:44","1","1");
INSERT INTO tricycle VALUES("13","13","Cardiac Arrest","56","Harry","9","18","1","Pending","2019-03-26 22:06:39","1","1");



CREATE TABLE `tricycle_registration` (
  `trireg_id` int(6) NOT NULL AUTO_INCREMENT,
  `tricycle_id` int(6) DEFAULT NULL,
  `regfee` varchar(30) DEFAULT NULL,
  `regsticker` varchar(30) DEFAULT NULL,
  `confirm` varchar(30) DEFAULT NULL,
  `inspect` varchar(30) DEFAULT NULL,
  `superv` varchar(30) DEFAULT NULL,
  `farerate` varchar(30) DEFAULT NULL,
  `platesticker` varchar(30) DEFAULT NULL,
  `others` varchar(30) DEFAULT NULL,
  `total` varchar(30) DEFAULT NULL,
  `payment_date` varchar(30) DEFAULT NULL,
  `effective_date` varchar(30) DEFAULT NULL,
  `expiration` varchar(30) DEFAULT NULL,
  `registration_status` varchar(30) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`trireg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO tricycle_registration VALUES("1","1","","","","","","","","","","","","","","2019-03-01 20:12:44","1","1");
INSERT INTO tricycle_registration VALUES("2","2","","","","","","","","","","","","","","2019-03-01 19:56:36","1","1");
INSERT INTO tricycle_registration VALUES("3","3","","","","","","","","","","","","","","2019-03-19 04:18:36","1","1");
INSERT INTO tricycle_registration VALUES("4","4","","","","","","","","","","","","","","2019-03-19 04:20:33","1","1");
INSERT INTO tricycle_registration VALUES("5","5","","","","","","","","","","","","","","2019-03-19 04:22:11","1","1");
INSERT INTO tricycle_registration VALUES("6","6","","","","","","","","","","","","","","2019-03-19 03:37:19","1","1");
INSERT INTO tricycle_registration VALUES("7","7","","","","","","","","","","","","","","2019-03-19 03:39:11","1","1");
INSERT INTO tricycle_registration VALUES("8","8","","","","","","","","","","","","","","2019-03-19 03:41:17","1","1");
INSERT INTO tricycle_registration VALUES("9","9","","","","","","","","","","","","","","2019-03-20 05:00:07","1","1");
INSERT INTO tricycle_registration VALUES("10","10","","","","","","","","","","","","","","2019-03-20 05:36:30","1","1");
INSERT INTO tricycle_registration VALUES("11","11","","","","","","","","","","","","","","2019-03-26 17:22:26","1","1");
INSERT INTO tricycle_registration VALUES("12","12","","","","","","","","","","","","","","2019-03-26 22:02:44","1","1");
INSERT INTO tricycle_registration VALUES("13","13","","","","","","","","","","","","","","2019-03-26 22:06:39","1","1");



CREATE TABLE `user_admin` (
  `user_id` int(6) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(15) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `birthday` varchar(15) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `position` varchar(15) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `created_by` int(6) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user_admin VALUES("1","Diana","Alconera","Tolin","diana.tolin","dianatolin","09194514179","11/25/1997","Female","Admin","2019-03-01 00:00:00","0","");
INSERT INTO user_admin VALUES("2","Charlene","Marie","Santiago","USER-2","Apple","09053155047","07/17/1997","Female","Assistant Chief","2019-03-20 04:54:51","1","1");

