<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'view_yearly_registration'){
	$date_now = date('Y-m');

	$stmt = $db->prepare("SELECT * FROM member m JOIN member_registration mr
		ON mr.member_id = m.member_id
		WHERE CONCAT(SUBSTRING(expiration, 7),'-',SUBSTRING(expiration, 1, 2)) = ? AND registration_status = 'Active'");
	$stmt->bindParam(1, $date_now);
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'] ?></td>
			<td><?php echo $row['expiration'] ?></td>
			<td><?php echo $row['payment_date'] ?></td>
			<td>
				<button class="btn btn-xs btn-success renew-member" data-id="<?php echo $row['memreg_id']; ?>" data-member-id="<?php echo $row['member_id'] ?>"> Renew
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'renew_member'){
	$stat = 1;
	$default_created = 1;
	// print_r($_POST);exit;
	// CREATE INVOICE
	$stmt3 = $db->prepare("INSERT INTO member_registration (member_id, date_created, created_by, status) VALUES (?,?,?,?)");

	$stmt3->bindParam(1, $_POST['member_id']);
	$stmt3->bindParam(2, date("Y-m-d H:i:s"));
	$stmt3->bindParam(3, $default_created);
	$stmt3->bindParam(4, $stat);

	$stmt3->execute();

	// UPDATE LATEST TRANSACTION ID
	$trans_id = $db->lastInsertId();
	$stmt2 = $db->prepare("UPDATE member SET memreg_id = ? WHERE member_id = ?");
	$stmt2->bindParam(1, $trans_id);
	$stmt2->bindParam(2, $_POST['member_id']);
	$stmt2->execute();

	// UPDATE OLD MEMBER REGISTRATION TO NOT ACTIVE
	$reg_stat_i = 'Inactive';
	$stmt3 = $db->prepare("UPDATE member_registration SET registration_status=? WHERE member_id = ?");
	$stmt3->bindParam(1, $reg_stat_i);
	$stmt3->bindParam(2, $_POST['member_id']);
	$stmt3->execute();
	// MEMBER REGISTRATION NEW
	$reg_stat_a = 'Active';
	$stmt1 = $db->prepare("UPDATE member_registration SET regfee=?, regsticker=?, 
		confirm=?, inspect=?, superv=?, farerate=?, platesticker=?, others=?,
		payment_date=?, effective_date=?, expiration=?, total=?, registration_status=? WHERE memreg_id = ?");
	
	$total = $_POST['regfee'] + $_POST['regsticker'] + $_POST['confirm'] +
			 $_POST['inspect'] + $_POST['superv'] + $_POST['farerate'] + 
			 $_POST['platesticker'] + $_POST['others'];

	$stmt1->bindParam(1, $_POST['regfee']);
	$stmt1->bindParam(2, $_POST['regsticker']);
	$stmt1->bindParam(3, $_POST['confirm']);
	$stmt1->bindParam(4, $_POST['inspect']);
	$stmt1->bindParam(5, $_POST['superv']);
	$stmt1->bindParam(6, $_POST['farerate']);
	$stmt1->bindParam(7, $_POST['platesticker']);
	$stmt1->bindParam(8, $_POST['others']);
	$stmt1->bindParam(9, $_POST['payment-date']);
	$stmt1->bindParam(10, $_POST['effective-date']);
	$stmt1->bindParam(11, $_POST['expiration']);
	$stmt1->bindParam(12, $total);
	$stmt1->bindParam(13, $reg_stat_a);
	$stmt1->bindParam(14, $trans_id);
	$stmt1->execute();

	// ACTIVE
	$stmt = $db->prepare("UPDATE member SET member_status=? WHERE member_id = ?");
	$mem_stat = 'Active';
	$stmt->bindParam(1, $mem_stat);
	$stmt->bindParam(2, $_POST['member_id']);
	$stmt->execute();
} else if($action == 'view_renewal_franchise'){
	$date_now = date('Y-m');

	$stmt = $db->prepare("SELECT * FROM tricycle_registration tr JOIN tricycle t
		ON tr.tricycle_id = t.tricycle_id JOIN member m ON m.member_id = t.member_id
		WHERE CONCAT(SUBSTRING(expiration, 7),'-',SUBSTRING(expiration, 1, 2)) = ? AND
		registration_status='Active'");
	$stmt->bindParam(1, $date_now);
	$stmt->execute();

	while($row = $stmt->fetch()){

		?>
		<tr>
			<td><?php echo $row['brand'].' - '.$row['plate_no'] ?></td>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'] ?></td>
			<td><?php echo $row['expiration'] ?></td>
			<td><?php echo $row['payment_date'] ?></td>
			<td>
				<button class="btn btn-xs btn-success renew-tricycle" data-id="<?php echo $row['trireg_id']; ?>" data-tri-id="<?php echo $row['tricycle_id'] ?>"> Renew
				</button>
			</td>
		</tr>
		<?php
	}
} else if($action == 'renew_tricycle'){
	$stat = 1;
	$default_created = 1;
	// print_r($_POST);exit;
	// CREATE INVOICE
	$stmt3 = $db->prepare("INSERT INTO tricycle_registration (tricycle_id, date_created, created_by, status) VALUES (?,?,?,?)");

	$stmt3->bindParam(1, $_POST['tricycle_id']);
	$stmt3->bindParam(2, date("Y-m-d H:i:s"));
	$stmt3->bindParam(3, $default_created);
	$stmt3->bindParam(4, $stat);

	$stmt3->execute();

	// UPDATE LATEST TRANSACTION ID
	$trans_id = $db->lastInsertId();
	$stmt2 = $db->prepare("UPDATE tricycle SET trireg_id = ? WHERE tricycle_id = ?");
	$stmt2->bindParam(1, $trans_id);
	$stmt2->bindParam(2, $_POST['tricycle_id']);
	$stmt2->execute();

	// UPDATE OLD MEMBER REGISTRATION TO NOT ACTIVE
	$reg_stat_i = 'Inactive';
	$stmt3 = $db->prepare("UPDATE tricycle_registration SET registration_status=? WHERE tricycle_id = ?");
	$stmt3->bindParam(1, $reg_stat_i);
	$stmt3->bindParam(2, $_POST['tricycle_id']);
	$stmt3->execute();
	// MEMBER REGISTRATION NEW
	$reg_stat_a = 'Active';
	$stmt1 = $db->prepare("UPDATE tricycle_registration 
		SET superv=?, farerate=?, others=?, payment_date=?, effective_date=?,
		expiration=?, total=?, registration_status=? WHERE trireg_id = ?");
	
	$total = $_POST['superv'] + $_POST['farerate'] + $_POST['others'];

	$stmt1->bindParam(1, $_POST['superv']);
	$stmt1->bindParam(2, $_POST['farerate']);
	$stmt1->bindParam(3, $_POST['others']);
	$stmt1->bindParam(4, $_POST['payment-date']);
	$stmt1->bindParam(5, $_POST['effective-date']);
	$stmt1->bindParam(6, $_POST['expiration']);
	$stmt1->bindParam(7, $total);
	$stmt1->bindParam(8, $reg_stat_a);
	$stmt1->bindParam(9, $trans_id);
	$stmt1->execute();

	// ACTIVE
	$stmt = $db->prepare("UPDATE tricycle SET tricycle_status=? WHERE tricycle_id = ?");
	$mem_stat = 'Active';
	$stmt->bindParam(1, $mem_stat);
	$stmt->bindParam(2, $_POST['tricycle_id']);
	$stmt->execute();
}

?>