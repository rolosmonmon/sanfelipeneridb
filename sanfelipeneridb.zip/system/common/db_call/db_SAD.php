<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == '_download_database'){
	// $stmt = $db->prepare('SELECT * FROM user_admin WHERE username=? and password=?');
	// $stmt->bindParam(1, $_POST['username']);
	// $stmt->bindParam(2, $_POST['old']);
	// $stmt->execute();
	// $row = $stmt->fetch();
	$user = $username;
	$name = 'toda_db';
	$host = $servername;
	$pass = $password;

	// $link = mysql_connect($host,$user,$pass);
	$link = new mysqli($host, $user, $pass, $name);
	// mysql_select_db($name,$link);
	
	$tables = array();
	// $result = mysql_query('SHOW TABLES');
	$result = $link->query('SHOW TABLES');
	while($row = $result->fetch_assoc())
	{
		$tables[] = $row[0];
	}

	$return = '';
	//cycle through
	foreach($tables as $table)
	{
		$result = $link->query('SELECT * FROM '.$table);
		$num_fields = $result->num_rows;
		
		$return.= 'DROP TABLE '.$table.';';
		$row2 = $link->query('SHOW CREATE TABLE '.$table)->fetch_assoc();
		$return.= "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = $result->fetch_assoc())
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j < $num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j < ($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";
	}
	//~~ REPLACE THIS
	// //save file
	// $handle = fopen('db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql','w+');
	// fwrite($handle,$return);
	// fclose($handle);

	//~~ TO THIS
	$file = 'db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql';
	//save file
	$handle = fopen($file,'w+');
	fwrite($handle,$return);
	fclose($handle);

	print_r($file);
} else if($action == 'download_database'){
	$host = "localhost";
	$username = "root";
	$password = "";
	$database_name = "toda_db";

	// Get connection object and set the charset
	$conn = mysqli_connect($host, $username, $password, $database_name);
	$conn->set_charset("utf8");


	// Get All Table Names From the Database
	$tables = array();
	$sql = "SHOW TABLES";
	$result = mysqli_query($conn, $sql);

	while ($row = mysqli_fetch_row($result)) {
	    $tables[] = $row[0];
	}

	$sqlScript = "";
	foreach ($tables as $table) {
	    
	    // Prepare SQLscript for creating table structure
	    $query = "SHOW CREATE TABLE $table";
	    $result = mysqli_query($conn, $query);
	    $row = mysqli_fetch_row($result);
	    
	    $sqlScript .= "\n\n" . $row[1] . ";\n\n";
	    
	    
	    $query = "SELECT * FROM $table";
	    $result = mysqli_query($conn, $query);
	    
	    $columnCount = mysqli_num_fields($result);
	    
	    // Prepare SQLscript for dumping data for each table
	    for ($i = 0; $i < $columnCount; $i ++) {
	        while ($row = mysqli_fetch_row($result)) {
	            $sqlScript .= "INSERT INTO $table VALUES(";
	            for ($j = 0; $j < $columnCount; $j ++) {
	                $row[$j] = $row[$j];
	                
	                if (isset($row[$j])) {
	                    $sqlScript .= '"' . $row[$j] . '"';
	                } else {
	                    $sqlScript .= '""';
	                }
	                if ($j < ($columnCount - 1)) {
	                    $sqlScript .= ',';
	                }
	            }
	            $sqlScript .= ");\n";
	        }
	    }
	    
	    $sqlScript .= "\n"; 
	}

	if(!empty($sqlScript))
	{
	    // Save the SQL script to a backup file
	    $backup_file_name = $database_name . '_backup_' . time() . '.sql';
	    $fileHandler = fopen($backup_file_name, 'w+');
	    $number_of_lines = fwrite($fileHandler, $sqlScript);
	    fclose($fileHandler); 
		print_r($backup_file_name);

	 //    // Download the SQL backup file to the browser
	 //    header('Content-Description: File Transfer');
	 //    header('Content-Type: application/octet-stream');
	 //    header('Content-Disposition: attachment; filename=' . basename($backup_file_name));
	 //    header('Content-Transfer-Encoding: binary');
	 //    header('Expires: 0');
	 //    header('Cache-Control: must-revalidate');
	 //    header('Pragma: public');
	 //    header('Content-Length: ' . filesize($backup_file_name));
	 //    ob_clean();
	 //    flush();
	 //    readfile($backup_file_name);
	 //    exec('rm ' . $backup_file_name); 

		// //save file
		// $handle = fopen($backup_file_name,'w+');
		// fwrite($handle,$return);
		// fclose($handle);

	}

} else if($action == '___download_database'){
	//ENTER THE RELEVANT INFO BELOW
    $mysqlUserName      = "root";
    $mysqlPassword      = "";
    $mysqlHostName      = "localhost";
    $DbName             = "toda_db";
    $backup_name        = "mybackup.sql";
    $tables             = array("archive", "change_ownership", "enforcer", "member", "member_registration", "sms_table", "toda_name","toda_officer","tricycle","tricycle_registration","user_admin");

   //or add 5th parameter(array) of specific tables:    array("mytable1","mytable2","mytable3") for multiple tables

    Export_Database($mysqlHostName,$mysqlUserName,$mysqlPassword,$DbName,  $tables=false, $backup_name=false );

    function Export_Database($host,$user,$pass,$name,  $tables=false, $backup_name=false )
    {
        $mysqli = new mysqli($host,$user,$pass,$name);
        $mysqli->select_db($name);
        $mysqli->query("SET NAMES 'utf8'");

        $queryTables    = $mysqli->query('SHOW TABLES');
        while($row = $queryTables->fetch_row())
        {
            $target_tables[] = $row[0];
        }
        if($tables !== false)
        {
            $target_tables = array_intersect( $target_tables, $tables);
        }
        foreach($target_tables as $table)
        {
            $result         =   $mysqli->query('SELECT * FROM '.$table);
            $fields_amount  =   $result->field_count;
            $rows_num=$mysqli->affected_rows;
            $res            =   $mysqli->query('SHOW CREATE TABLE '.$table);
            $TableMLine     =   $res->fetch_row();
            $content        = (!isset($content) ?  '' : $content) . "\n\n".$TableMLine[1].";\n\n";

            for ($i = 0, $st_counter = 0; $i < $fields_amount;   $i++, $st_counter=0)
            {
                while($row = $result->fetch_row())
                { //when started (and every after 100 command cycle):
                    if ($st_counter%100 == 0 || $st_counter == 0 )
                    {
                            $content .= "\nINSERT INTO ".$table." VALUES";
                    }
                    $content .= "\n(";
                    for($j=0; $j<$fields_amount; $j++)
                    {
                        $row[$j] = str_replace("\n","\\n", addslashes($row[$j]) );
                        if (isset($row[$j]))
                        {
                            $content .= '"'.$row[$j].'"' ;
                        }
                        else
                        {
                            $content .= '""';
                        }
                        if ($j<($fields_amount-1))
                        {
                                $content.= ',';
                        }
                    }
                    $content .=")";
                    //every after 100 command cycle [or at last line] ....p.s. but should be inserted 1 cycle eariler
                    if ( (($st_counter+1)%100==0 && $st_counter!=0) || $st_counter+1==$rows_num)
                    {
                        $content .= ";";
                    }
                    else
                    {
                        $content .= ",";
                    }
                    $st_counter=$st_counter+1;
                }
            } $content .="\n\n\n";
        }
        //$backup_name = $backup_name ? $backup_name : $name."___(".date('H-i-s')."_".date('d-m-Y').")__rand".rand(1,11111111).".sql";
        $date = date("Y-m-d");
        $backup_name = $backup_name ? $backup_name : $name.".$date.sql";
        header('Content-Type: application/octet-stream');
        header("Content-Transfer-Encoding: Binary");
        header("Content-disposition: attachment; filename=\"".$backup_name."\"");
         // alert(response);
        //~~ FROM THIS
         // echo $content; exit;
       //~~ TO THIS
        echo $backup_name;
    }
} else if($action == 'view_clients_payment'){
	$stmt = $db->prepare('SELECT *, 
		CONCAT(m.last_name,", ",m.first_name," ",m.middle_name) AS name
		FROM member m JOIN change_ownership c ON c.member_id_to = m.member_id
        WHERE c.status = 1');
	$stmt->execute();

	while($row = $stmt->fetch()){
		$filename = $row['name'].'-'.$row['payment_date'].'-'.strtotime('now').'.csv';
		?>
		<tr>
			<td><?php echo $row['name'] ?></td>
			<td><?php echo $row['payment_date'] ?></td>
			<td><?php echo 'PHP '.$row['total'] ?></td>
			<td><div class="btn btn-primary print-receipt" data-id="<?php echo $row['change_id']?>">Print Receipt</div></td>
			
		</tr>
		<?php
	}

	// exit;
} else if($action == 'download_receipt'){
	// $filename = $_GET['filename'];
	// header('Content-Type: text/csv');
	// header('Content-Disposition: attachment; filename="'.$filename.'"');
	// // LINE 1
	// $data[0] = 'San Felipe Neri Cemetery';
	// $data[0] = 'Official Receipt';
	// $data[1] = '';
	$stmt = $db->prepare('SELECT *, 
		CONCAT(m.last_name,", ",m.first_name," ",m.middle_name) AS name
		FROM member m JOIN change_ownership c ON c.member_id_to = m.member_id
        WHERE c.status = 1 and change_id='.$_GET['change_id']);
	$stmt->execute();

	while($row = $stmt->fetch()){
		$data['name'] = $row['name'];
		$data['original-contract'] = ($row['regfee'] == '') ? 0 : $row['regfee'];
		$data['valid-id'] = ($row['mch'] == '') ? 0 : $row['mch'];
		$data['official-receipt'] = ($row['petition'] == '') ? 0 : $row['petition'];
		$data['transfer-fee'] = ($row['confirm'] == '') ? 0 : $row['confirm'];
		$data['contract-fee'] = ($row['inspect'] == '') ? 0 : $row['inspect'];
		$data['govt-requirements'] = ($row['superv'] == '') ? 0 : $row['superv'];
		$data['others'] = ($row['others'] == '') ? 0 : $row['others'];
		$data['total-sales'] = $row['regfee'] + $row['mch'] + $row['petition'] + $row['confirm'] + $row['inspect'] + $row['superv'] + $row['others'];
	}
	print_r(json_encode($data));
	// fclose($fp);
} else if($action == 'view_monthly_report'){
	
	$stmt = $db->prepare('SELECT *, SUM(regfee) as sum_regfee, SUM(mch) as sum_mch,
		SUM(petition) as sum_petition, SUM(confirm) as sum_confirm,
		SUM(inspect) as sum_inspect, SUM(superv) as sum_superv, SUM(others) as sum_others,
		(SUM(regfee) + SUM(mch) + SUM(petition) + SUM(confirm) + SUM(inspect) + SUM(superv) + SUM(others)) as sum_per_year,
		MONTH(STR_TO_DATE(payment_date, "%m/%d/%Y")) as month_report,
		YEAR(STR_TO_DATE(payment_date, "%m/%d/%Y")) as year_report
		FROM change_ownership c
        WHERE c.status = 1 and STR_TO_DATE(payment_date, "%m/%d/%Y") > "2015/01/01" and STR_TO_DATE(payment_date, "%m/%d/%Y") < "2019/12/31"
        GROUP BY year_report, month_report
        ORDER BY year_report, month_report');
	$stmt->execute();

	for ($i=2015; $i <= 2019 ; $i++) {
		for ($x=1; $x<=12 ; $x++) {
			$data[$i][$x]['original-contract'] = 0;
			$data[$i][$x]['valid-id'] = 0;
			$data[$i][$x]['official-receipt'] = 0;
			$data[$i][$x]['transfer-fee'] = 0;
			$data[$i][$x]['contract-fee'] = 0;
			$data[$i][$x]['govt-requirements'] = 0;
			$data[$i][$x]['others'] = 0;
			$data[$i][$x]['per_year'] = 0;
		}
		$total_sum_regfee[$i] = 0;
		$total_sum_mch[$i] = 0;
		$total_sum_petition[$i] = 0;
		$total_sum_confirm[$i] = 0;
		$total_sum_inspect[$i] = 0;
		$total_sum_superv[$i] = 0;
		$total_sum_others[$i] = 0;
		$total_sum_per_year[$i] = 0;
		$msg[$i] = '';
	}

	while($row = $stmt->fetch()){
		$data[$row['year_report']][$row['month_report']]['original-contract'] = $row['sum_regfee'];
		$data[$row['year_report']][$row['month_report']]['valid-id'] = $row['sum_mch'];
		$data[$row['year_report']][$row['month_report']]['official-receipt'] = $row['sum_petition'];
		$data[$row['year_report']][$row['month_report']]['transfer-fee'] = $row['sum_confirm'];
		$data[$row['year_report']][$row['month_report']]['contract-fee'] = $row['sum_inspect'];
		$data[$row['year_report']][$row['month_report']]['govt-requirements'] = $row['sum_superv'];
		$data[$row['year_report']][$row['month_report']]['others'] = $row['sum_others'];
		$data[$row['year_report']][$row['month_report']]['per_year'] = $row['sum_per_year'];

		$total_sum_regfee[$row['year_report']] += $row['sum_regfee'];
		$total_sum_mch[$row['year_report']] += $row['sum_mch'];
		$total_sum_petition[$row['year_report']] += $row['sum_petition'];
		$total_sum_confirm[$row['year_report']] += $row['sum_confirm'];
		$total_sum_inspect[$row['year_report']] += $row['sum_inspect'];
		$total_sum_superv[$row['year_report']] += $row['sum_superv'];
		$total_sum_others[$row['year_report']] += $row['sum_others'];
		$total_sum_per_year[$row['year_report']] += $row['sum_per_year'];
	}
	
	for ($i=2015; $i <= 2019 ; $i++) {
		$yearlyMsg = '';
		for ($x=1; $x <=12 ; $x++) { 
			$yearlyMsg .= '<tr><td>'.date('F', strtotime((string) $x.'/01/'.$i)).'</td>'.
			'<td>'.$data[$i][$x]['original-contract'].'</td>'.
			'<td>'.$data[$i][$x]['valid-id'].'</td>'.
			'<td>'.$data[$i][$x]['official-receipt'].'</td>'.
			'<td>'.$data[$i][$x]['transfer-fee'].'</td>'.
			'<td>'.$data[$i][$x]['contract-fee'].'</td>'.
			'<td>'.$data[$i][$x]['govt-requirements'].'</td>'.
			'<td>'.$data[$i][$x]['others'].'</td>'.
			'<td>'.$data[$i][$x]['per_year'].'</td>'.

			'</tr>';
		}
		$yearlyMsg .= '<tr><td>TOTAL</td>'.
			'<td>'.$total_sum_regfee[$i].'</td>'.
			'<td>'.$total_sum_mch[$i].'</td>'.
			'<td>'.$total_sum_petition[$i].'</td>'.
			'<td>'.$total_sum_confirm[$i].'</td>'.
			'<td>'.$total_sum_inspect[$i].'</td>'.
			'<td>'.$total_sum_superv[$i].'</td>'.
			'<td>'.$total_sum_others[$i].'</td>'.
			'<td>'.$total_sum_per_year[$i].'</td>'.

			'</tr>';
		$msg[$i] .= $yearlyMsg;
	}


	print_r(json_encode($msg));
	
} else if($action == 'view_yearly_report'){
	$stmt = $db->prepare('SELECT *, SUM(regfee) as sum_regfee, SUM(mch) as sum_mch,
		SUM(petition) as sum_petition, SUM(confirm) as sum_confirm,
		SUM(inspect) as sum_inspect, SUM(superv) as sum_superv, SUM(others) as sum_others,
		(SUM(regfee) + SUM(mch) + SUM(petition) + SUM(confirm) + SUM(inspect) + SUM(superv) + SUM(others)) as sum_per_year,
		YEAR(STR_TO_DATE(payment_date, "%m/%d/%Y")) as year_report
		FROM change_ownership c
        WHERE c.status = 1 and STR_TO_DATE(payment_date, "%m/%d/%Y") > "2015/01/01" and STR_TO_DATE(payment_date, "%m/%d/%Y") < "2019/12/31"
        GROUP BY year_report');
	$stmt->execute();

	for ($i=2015; $i <= 2019 ; $i++) {
		$data[$i]['original-contract'] = 0;
		$data[$i]['valid-id'] = 0;
		$data[$i]['official-receipt'] = 0;
		$data[$i]['transfer-fee'] = 0;
		$data[$i]['contract-fee'] = 0;
		$data[$i]['govt-requirements'] = 0;
		$data[$i]['others'] = 0;
		$data[$i]['per_year'] = 0;
	}
	$total_sum_regfee = 0;
	$total_sum_mch = 0;
	$total_sum_petition = 0;
	$total_sum_confirm = 0;
	$total_sum_inspect = 0;
	$total_sum_superv = 0;
	$total_sum_others = 0;
	$total_sum_per_year = 0;

	while($row = $stmt->fetch()){
		$data[$row['year_report']]['original-contract'] = $row['sum_regfee'];
		$data[$row['year_report']]['valid-id'] = $row['sum_mch'];
		$data[$row['year_report']]['official-receipt'] = $row['sum_petition'];
		$data[$row['year_report']]['transfer-fee'] = $row['sum_confirm'];
		$data[$row['year_report']]['contract-fee'] = $row['sum_inspect'];
		$data[$row['year_report']]['govt-requirements'] = $row['sum_superv'];
		$data[$row['year_report']]['others'] = $row['sum_others'];
		$data[$row['year_report']]['per_year'] = $row['sum_per_year'];

		$total_sum_regfee += $row['sum_regfee'];
		$total_sum_mch += $row['sum_mch'];
		$total_sum_petition += $row['sum_petition'];
		$total_sum_confirm += $row['sum_confirm'];
		$total_sum_inspect += $row['sum_inspect'];
		$total_sum_superv += $row['sum_superv'];
		$total_sum_others += $row['sum_others'];
		$total_sum_per_year += $row['sum_per_year'];
	}
	$msg = '';
	for ($i=2015; $i <= 2019 ; $i++) {
		$msg .= '<tr><td>'.(string) $i.'</td>'.
			'<td>'.$data[$i]['original-contract'].'</td>'.
			'<td>'.$data[$i]['valid-id'].'</td>'.
			'<td>'.$data[$i]['official-receipt'].'</td>'.
			'<td>'.$data[$i]['transfer-fee'].'</td>'.
			'<td>'.$data[$i]['contract-fee'].'</td>'.
			'<td>'.$data[$i]['govt-requirements'].'</td>'.
			'<td>'.$data[$i]['others'].'</td>'.
			'<td>'.$data[$i]['per_year'].'</td>'.

			'</tr>';	
	}
		$msg .= '<tr><td>TOTAL</td>'.
			'<td>'.$total_sum_regfee.'</td>'.
			'<td>'.$total_sum_mch.'</td>'.
			'<td>'.$total_sum_petition.'</td>'.
			'<td>'.$total_sum_confirm.'</td>'.
			'<td>'.$total_sum_inspect.'</td>'.
			'<td>'.$total_sum_superv.'</td>'.
			'<td>'.$total_sum_others.'</td>'.
			'<td>'.$total_sum_per_year.'</td>'.

			'</tr>';

		print_r($msg);
	// print_r(json_encode($data));
	exit;
}

?>
