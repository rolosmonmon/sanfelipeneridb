<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'add_member'){
	$stmt = $db->prepare("INSERT INTO member (first_name, last_name, middle_name, contact, birthday, gender, date_created, created_by, status, member_status) VALUES (?,?,?,?,?,?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;
	$mem_stat = 'Pending';
	$stmt->bindParam(1, $_POST['first-name']);
	$stmt->bindParam(2, $_POST['last-name']);
	$stmt->bindParam(3, $_POST['middle-name']);
	$stmt->bindParam(4, $_POST['contact']);
	$stmt->bindParam(5, $_POST['birthday']);
	$stmt->bindParam(6, $_POST['gender']);
	$stmt->bindParam(7, date("Y-m-d H:i:s"));
	$stmt->bindParam(8, $default_created);
	$stmt->bindParam(9, $stat);
	$stmt->bindParam(10, $mem_stat);
	$stmt->execute();

	// CREATE INVOICE
	$reg_stat = 'Active';
	$stmt1 = $db->prepare("INSERT INTO member_registration (member_id, date_created, created_by, status, registration_status) VALUES (?,?,?,?,?)");
	$mem_id = $db->lastInsertId();

	$stmt1->bindParam(1, $mem_id);
	$stmt1->bindParam(2, date("Y-m-d H:i:s"));
	$stmt1->bindParam(3, $default_created);
	$stmt1->bindParam(4, $stat);
	$stmt1->bindParam(5, $reg_stat);

	$stmt1->execute();

	// UPDATE LATEST TRANSACTION ID
	$trans_id = $db->lastInsertId();
	$stmt2 = $db->prepare("UPDATE member SET memreg_id = ? WHERE member_id = ?");
	$stmt2->bindParam(1, $trans_id);
	$stmt2->bindParam(2, $mem_id);
	$stmt2->execute();

} else if($action == 'view_member'){
	$stmt = $db->prepare('SELECT * FROM member WHERE status = 1');
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		if($row['member_status'] == 'Pending'){
			$btn = 'warning';
			$class = 'pending-member';
		} else if($row['member_status'] == 'Active'){
			$btn = 'success';
			$class = 'history-member';
		} else {
			$btn = 'danger';
			$class = 'history-member';
		}
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']; ?></td>
			<td><?php echo $row['contact'] ?></td>
			<td><?php echo ucfirst($row['birthday']) ?></td>
			<td><?php echo $row['gender'] ?></td>
			<td><button class="btn btn-xs btn-<?php echo $btn.' '.$class; ?>" data-id="<?php echo $row['memreg_id'] ?>" data-mem-id="<?php echo $row['member_id'] ?>"> <?php echo $row['member_status'] ?>
				</button></td>
			<td>
				<button class="btn btn-xs btn-info member-edit" data-id="<?php echo $row['member_id'] ?>"> Update
				</button>
				<button class="btn btn-xs btn-danger member-delete" data-id="<?php echo $row['member_id'] ?>"> Delete
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'get_member'){
	$stmt = $db->prepare('SELECT * FROM member WHERE member_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'update_member'){
	$stmt1 = $db->prepare("UPDATE member SET first_name=?, middle_name=?, last_name=?, contact=?, birthday=?, gender=? WHERE member_id = ?");
	$stmt1->bindParam(1, $_POST['first-name']);
	$stmt1->bindParam(2, $_POST['middle-name']);
	$stmt1->bindParam(3, $_POST['last-name']);
	$stmt1->bindParam(4, $_POST['contact']);
	$stmt1->bindParam(5, $_POST['birthday']);
	$stmt1->bindParam(6, $_POST['gender']);
	$stmt1->bindParam(7, $_POST['id']);
	
	$stmt1->execute();
	// print_r($_POST);
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'delete_member'){
	$delete = 0;
	$stmt1 = $db->prepare("UPDATE member SET status = ? WHERE member_id = ?");
	$stmt1->bindParam(1, $delete);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();
} else if($action == 'view_pending_member'){
	$stmt = $db->prepare('SELECT * FROM member_registration WHERE memreg_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'pending_member'){
	$stmt1 = $db->prepare("UPDATE member_registration SET regfee=?, regsticker=?, 
		confirm=?, inspect=?, superv=?, farerate=?, platesticker=?, others=?,
		payment_date=?, effective_date=?, expiration=?, total=? WHERE memreg_id = ?");
	
	$total = $_POST['regfee'] + $_POST['regsticker'] + $_POST['confirm'] +
			 $_POST['inspect'] + $_POST['superv'] + $_POST['farerate'] + 
			 $_POST['platesticker'] + $_POST['others'];

	$stmt1->bindParam(1, $_POST['regfee']);
	$stmt1->bindParam(2, $_POST['regsticker']);
	$stmt1->bindParam(3, $_POST['confirm']);
	$stmt1->bindParam(4, $_POST['inspect']);
	$stmt1->bindParam(5, $_POST['superv']);
	$stmt1->bindParam(6, $_POST['farerate']);
	$stmt1->bindParam(7, $_POST['platesticker']);
	$stmt1->bindParam(8, $_POST['others']);
	$stmt1->bindParam(9, $_POST['payment-date']);
	$stmt1->bindParam(10, $_POST['effective-date']);
	$stmt1->bindParam(11, $_POST['expiration']);
	$stmt1->bindParam(12, $total);
	$stmt1->bindParam(13, $_POST['id']);
	$stmt1->execute();
} else if($action == 'complete_member'){
	$stmt1 = $db->prepare("UPDATE member_registration SET regfee=?, regsticker=?, 
		confirm=?, inspect=?, superv=?, farerate=?, platesticker=?, others=?,
		payment_date=?, effective_date=?, expiration=?, total=? WHERE memreg_id = ?");
	
	$total = $_POST['regfee'] + $_POST['regsticker'] + $_POST['confirm'] +
			 $_POST['inspect'] + $_POST['superv'] + $_POST['farerate'] + 
			 $_POST['platesticker'] + $_POST['others'];

	$stmt1->bindParam(1, $_POST['regfee']);
	$stmt1->bindParam(2, $_POST['regsticker']);
	$stmt1->bindParam(3, $_POST['confirm']);
	$stmt1->bindParam(4, $_POST['inspect']);
	$stmt1->bindParam(5, $_POST['superv']);
	$stmt1->bindParam(6, $_POST['farerate']);
	$stmt1->bindParam(7, $_POST['platesticker']);
	$stmt1->bindParam(8, $_POST['others']);
	$stmt1->bindParam(9, $_POST['payment-date']);
	$stmt1->bindParam(10, $_POST['effective-date']);
	$stmt1->bindParam(11, $_POST['expiration']);
	$stmt1->bindParam(12, $total);
	$stmt1->bindParam(13, $_POST['id']);
	$stmt1->execute();

	// ACTIVE
	$stmt = $db->prepare("UPDATE member SET member_status=?, availability=? WHERE member_id = ?");
	$mem_stat = 'Active'; $avail_stat = 'yes';
	$stmt->bindParam(1, $mem_stat);
	$stmt->bindParam(2, $avail_stat);
	$stmt->bindParam(3, $_POST['member_id']);
	$stmt->execute();

	// SEND A TEXT
	$stmt3 = $db->prepare('SELECT * FROM member m join member_registration mr
		ON m.memreg_id = mr.memreg_id WHERE m.member_id = ?');
	$stmt3->bindParam(1, $_POST['member_id']);
	$stmt3->execute();
	
	print_r(json_encode($stmt3->fetch(), true));

} else if($action == 'view_member_registration'){
	$stmt = $db->prepare('SELECT * FROM member_registration mr JOIN member m
	ON mr.member_id = m.member_id WHERE mr.status = 1 AND mr.member_id =?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']; ?></td>
			<td><?php echo $row['contact'] ?></td>
			<td><?php echo $row['payment_date'] ?></td>
			<td><?php echo $row['effective_date'] ?></td>
			<td><?php echo $row['expiration'] ?></td>
			<td><?php echo $row['total'] ?></td>
			<td>
				<button class="btn btn-xs btn-default print_receipt_member" data-id="<?php echo $row['memreg_id'] ?>"> Print Receipt
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'send_welcome_text'){
	$message = 'Salamat sa pagsali sa Toda ng San Juan! Maligayang Pagbiyahe! From: Transport Regulatory Board.';
	// print_r($_POST);
	$result = itexmo($_POST['contact'], $message, "TR-TRICY982682_IDL8E");
		if ($result == ""){
		echo "iTexMo: No response from server!!!
		Please check the METHOD used (CURL or CURL-LESS). If you are using CURL then try CURL-LESS and vice versa.	
		Please CONTACT US for help. ";	
		}else if ($result == 0){
		echo "Message Sent!";
		}
		else if($result == 4){	
		echo "Data was saved but you have erached the maximum number of text per day";
		}
		else{	
		echo "Error Num ". $result . " was encountered!";
		}
}


function itexmo($number,$message,$apicode){
	$ch = curl_init();
	$itexmo = array('1' => $number, '2' => $message, '3' => $apicode);
	curl_setopt($ch, CURLOPT_URL,"https://www.itexmo.com/php_api/api.php");
	curl_setopt($ch, CURLOPT_POST, 1);
	 curl_setopt($ch, CURLOPT_POSTFIELDS, 
	          http_build_query($itexmo));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	return curl_exec ($ch);
	curl_close ($ch);
}
?>

