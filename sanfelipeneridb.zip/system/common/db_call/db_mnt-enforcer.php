<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'add_enforcer'){
	$stmt = $db->prepare("INSERT INTO enforcer (first_name, last_name, middle_name, contact, birthday, gender, date_created, created_by, status) VALUES (?,?,?,?,?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;

	$stmt->bindParam(1, $_POST['first-name']);
	$stmt->bindParam(2, $_POST['last-name']);
	$stmt->bindParam(3, $_POST['middle-name']);
	$stmt->bindParam(4, $_POST['contact']);
	$stmt->bindParam(5, $_POST['birthday']);
	$stmt->bindParam(6, $_POST['gender']);
	$stmt->bindParam(7, date("Y-m-d H:i:s"));
	$stmt->bindParam(8, $default_created);
	$stmt->bindParam(9, $stat);
	$stmt->execute();
} else if($action == 'view_enforcer'){
	$stmt = $db->prepare('SELECT * FROM enforcer WHERE status = 1');
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']; ?></td>
			<td><?php echo $row['contact'] ?></td>
			<td><?php echo ucfirst($row['birthday']) ?></td>
			<td><?php echo $row['gender'] ?></td>
			<td>
				<button class="btn btn-xs btn-info enforcer-edit" data-id="<?php echo $row['enforcer_id'] ?>"> Update
				</button>
				<button class="btn btn-xs btn-danger enforcer-delete" data-id="<?php echo $row['enforcer_id'] ?>"> Delete
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'get_enforcer'){
	$stmt = $db->prepare('SELECT * FROM enforcer WHERE enforcer_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'update_enforcer'){
	$stmt1 = $db->prepare("UPDATE enforcer SET first_name=?, middle_name=?, last_name=?, contact=?, birthday=?, gender=? WHERE enforcer_id = ?");
	$stmt1->bindParam(1, $_POST['first-name']);
	$stmt1->bindParam(2, $_POST['middle-name']);
	$stmt1->bindParam(3, $_POST['last-name']);
	$stmt1->bindParam(4, $_POST['contact']);
	$stmt1->bindParam(5, $_POST['birthday']);
	$stmt1->bindParam(6, $_POST['gender']);
	$stmt1->bindParam(7, $_POST['id']);
	
	$stmt1->execute();
	// print_r($_POST);
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'delete_enforcer'){
	$delete = 0;
	$stmt1 = $db->prepare("UPDATE enforcer SET status = ? WHERE enforcer_id = ?");
	$stmt1->bindParam(1, $delete);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("INSERT INTO archive (id, table_name, deleted_by, date_created, status) VALUES (?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;
	$table = 'enforcer';

	$stmt->bindParam(1, $_POST['id']);
	$stmt->bindParam(2, $table);
	$stmt->bindParam(3, $_POST['deleted_by']);
	$stmt->bindParam(4, date("Y-m-d H:i:s"));
	$stmt->bindParam(5, $stat);
	$stmt->execute();
}

?>