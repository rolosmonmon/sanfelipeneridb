<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'add_tricycle'){
	$stmt = $db->prepare("INSERT INTO tricycle (chassis_no, plate_no, brand, motor_no, toda_id, date_created, created_by, status, tricycle_status, member_id) VALUES (?,?,?,?,?,?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;
	$tri_stat = 'Pending';
	$stmt->bindParam(1, $_POST['chassis-no']);
	$stmt->bindParam(2, $_POST['plate-no']);
	$stmt->bindParam(3, $_POST['brand']);
	$stmt->bindParam(4, $_POST['motor-no']);
	$stmt->bindParam(5, $_POST['toda-name']);
	$stmt->bindParam(6, date("Y-m-d H:i:s"));
	$stmt->bindParam(7, $default_created);
	$stmt->bindParam(8, $stat);
	$stmt->bindParam(9, $tri_stat);
	$stmt->bindParam(10, $_POST['member']);
	$stmt->execute();
	$tri_id = $db->lastInsertId();

	// CREATE INVOICE
	$stmt2 = $db->prepare("INSERT INTO tricycle_registration (tricycle_id, date_created, created_by, status) VALUES (?,?,?,?)");
	
	$stmt2->bindParam(1, $tri_id);
	$stmt2->bindParam(2, date("Y-m-d H:i:s"));
	$stmt2->bindParam(3, $default_created);
	$stmt2->bindParam(4, $stat);

	$stmt2->execute();
	$trireg_id = $db->lastInsertId();

	// UPDATE TRANSACTION ID
	$stmt1 = $db->prepare("UPDATE tricycle SET trireg_id=? WHERE tricycle_id = ?");

	$stmt1->bindParam(1, $trireg_id);
	$stmt1->bindParam(2, $tri_id);
	$stmt1->execute();

	// UPDATE MEMBER AVAILIBILITY
	$stmt1 = $db->prepare("UPDATE member SET availability=? WHERE member_id = ?");
	$avail_stat = 'no';
	$stmt1->bindParam(1, $avail_stat);
	$stmt1->bindParam(2, $_POST['member']);
	$stmt1->execute();

} else if($action == 'view_tricycle'){
	$stmt = $db->prepare('SELECT * FROM tricycle t JOIN toda_name tn 
		ON t.toda_id = tn.toda_id JOIN member m ON m.member_id = t.member_id
		WHERE t.status = 1');
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		if($row['tricycle_status'] == 'Pending'){
			$btn = 'warning';
			$class = 'tricycle_register';
		} else if($row['tricycle_status'] == 'Active'){
			$btn = 'success';
			$class = 'history-tricycle';
		} else {
			$btn = 'danger';
			$class = 'history-tricycle';
		}
		?>
		<tr>
			<td><?php echo $row['brand']; ?></td>
			<td><?php echo $row['plate_no'] ?></td>
			<td><?php echo $row['motor_no'] ?></td>
			<td><?php echo $row['chassis_no'] ?></td>
			<td>
				<div class="col-xs-5"><?php echo $row['toda_name'] ?></div>
				<div class="col-xs-5" 
					style="background-color: <?php echo $row['toda_color']; ?>">
					&nbsp;
				</div>
			</td>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'] ?></td>
			<!-- <td> -->
				<!-- <button class="btn btn-xs btn-<?php echo $btn.' '.$class; ?>" data-id="<?php echo $row['trireg_id'] ?>" data-tri-id="<?php echo $row['tricycle_id'] ?>"> <?php echo $row['tricycle_status'] ?> -->
				<!-- </button> -->
			<!-- </td> -->
			<td>
				<button class="btn btn-xs btn-info tricycle-edit" data-id="<?php echo $row['tricycle_id'] ?>"> Update
				</button>
				<button class="btn btn-xs btn-danger tricycle-delete"  data-mem-id="<?php echo $row['member_id'] ?>" data-id="<?php echo $row['tricycle_id'] ?>"> Delete
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'get_tricycle'){
	$stmt = $db->prepare('SELECT * FROM tricycle t JOIN member m 
		ON m.member_id = t.member_id WHERE tricycle_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'update_tricycle'){
	$stmt = $db->prepare("UPDATE tricycle SET chassis_no=?, plate_no=?, brand=?, motor_no=?, toda_id=? WHERE tricycle_id = ?");
	$stmt->bindParam(1, $_POST['chassis-no']);
	$stmt->bindParam(2, $_POST['plate-no']);
	$stmt->bindParam(3, $_POST['brand']);
	$stmt->bindParam(4, $_POST['motor-no']);
	$stmt->bindParam(5, $_POST['toda-name']);
	$stmt->bindParam(6, $_POST['id']);
	
	$stmt->execute();
	// print_r($_POST);
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'delete_tricycle'){
	$delete = 0;
	$stmt1 = $db->prepare("UPDATE tricycle SET status = ? WHERE tricycle_id = ?");
	$stmt1->bindParam(1, $delete);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$avail = 'yes';
	$stmt1 = $db->prepare("UPDATE member SET availability = ? WHERE member_id = ?");
	$stmt1->bindParam(1, $avail);
	$stmt1->bindParam(2, $_POST['member_id']);
	$stmt1->execute();
} else if($action == 'get_toda'){
	$stmt = $db->prepare('SELECT * FROM toda_name WHERE status = 1');
	// $stmt->bindParam(1, $_POST['id']);
	$stmt->execute();
	while($row = $stmt->fetch()){
		?>
		<option style="background-color: <?php echo $row['toda_color']; ?>" value="<?php echo $row['toda_id']; ?>"><?php echo $row['toda_name']?></option>
		<?php
	}
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'get_member'){
	$stmt = $db->prepare('SELECT * FROM member WHERE status = 1 
		AND availability = "yes" AND member_status = "Active"');
	// $stmt->bindParam(1, $_POST['id']);
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		?>
		<option value="<?php echo $row['member_id']; ?>">
			<?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']?>
		</option>
		<?php
	}
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'view_pending_tricycle'){
	$stmt = $db->prepare('SELECT * FROM tricycle_registration WHERE trireg_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'pending_tricycle'){
	$stmt1 = $db->prepare("UPDATE tricycle_registration SET regfee=?, regsticker=?, 
		confirm=?, inspect=?, superv=?, farerate=?, platesticker=?, others=?,
		payment_date=?, effective_date=?, expiration=?, total=? WHERE trireg_id = ?");
	
	$total = $_POST['regfee'] + $_POST['regsticker'] + $_POST['confirm'] +
			 $_POST['inspect'] + $_POST['superv'] + $_POST['farerate'] + 
			 $_POST['platesticker'] + $_POST['others'];

	$stmt1->bindParam(1, $_POST['regfee']);
	$stmt1->bindParam(2, $_POST['regsticker']);
	$stmt1->bindParam(3, $_POST['confirm']);
	$stmt1->bindParam(4, $_POST['inspect']);
	$stmt1->bindParam(5, $_POST['superv']);
	$stmt1->bindParam(6, $_POST['farerate']);
	$stmt1->bindParam(7, $_POST['platesticker']);
	$stmt1->bindParam(8, $_POST['others']);
	$stmt1->bindParam(9, $_POST['payment-date']);
	$stmt1->bindParam(10, $_POST['effective-date']);
	$stmt1->bindParam(11, $_POST['expiration']);
	$stmt1->bindParam(12, $total);
	$stmt1->bindParam(13, $_POST['id']);
	$stmt1->execute();
} else if($action == 'complete_tricycle'){
	$stmt1 = $db->prepare("UPDATE tricycle_registration SET regfee=?, regsticker=?, 
		confirm=?, inspect=?, superv=?, farerate=?, platesticker=?, others=?,
		payment_date=?, effective_date=?, expiration=?, total=? WHERE trireg_id = ?");
	
	$total = $_POST['regfee'] + $_POST['regsticker'] + $_POST['confirm'] +
			 $_POST['inspect'] + $_POST['superv'] + $_POST['farerate'] + 
			 $_POST['platesticker'] + $_POST['others'];

	$stmt1->bindParam(1, $_POST['regfee']);
	$stmt1->bindParam(2, $_POST['regsticker']);
	$stmt1->bindParam(3, $_POST['confirm']);
	$stmt1->bindParam(4, $_POST['inspect']);
	$stmt1->bindParam(5, $_POST['superv']);
	$stmt1->bindParam(6, $_POST['farerate']);
	$stmt1->bindParam(7, $_POST['platesticker']);
	$stmt1->bindParam(8, $_POST['others']);
	$stmt1->bindParam(9, $_POST['payment-date']);
	$stmt1->bindParam(10, $_POST['effective-date']);
	$stmt1->bindParam(11, $_POST['expiration']);
	$stmt1->bindParam(12, $total);
	$stmt1->bindParam(13, $_POST['id']);
	$stmt1->execute();

	// ACTIVE
	$stmt = $db->prepare("UPDATE tricycle SET tricycle_status=? WHERE tricycle_id = ?");
	$mem_stat = 'Active'; $avail_stat = 'yes';
	$stmt->bindParam(1, $mem_stat);
	$stmt->bindParam(2, $_POST['tri_id']);
	$stmt->execute();

	// SEND A TEXT
	$stmt3 = $db->prepare('SELECT * FROM tricycle t join member m
		ON m.member_id = t.member_id WHERE t.tricycle_id = ?');
	$stmt3->bindParam(1, $_POST['tri_id']);
	$stmt3->execute();
	
	print_r(json_encode($stmt3->fetch(), true));

}  else if($action == 'view_tricycle_registration'){
	$stmt = $db->prepare('SELECT * FROM tricycle_registration tr JOIN tricycle t
	ON tr.tricycle_id = t.tricycle_id JOIN member m ON m.member_id = t.member_id
	WHERE tr.status = 1 AND tr.tricycle_id =?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']; ?></td>
			<td><?php echo $row['contact'] ?></td>
			<td><?php echo $row['payment_date'] ?></td>
			<td><?php echo $row['effective_date'] ?></td>
			<td><?php echo $row['expiration'] ?></td>
			<td><?php echo $row['total'] ?></td>
			<td>
				<button class="btn btn-xs btn-default print_receipt_member" data-id="<?php echo $row['memreg_id'] ?>"> Print Receipt
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'send_welcome_text'){
	$message = 'Nakarehistro na ang iyong traysikel! Maligayang Pagbiyahe! From: Transport Regulatory Board.';
	// print_r($_POST);
	$result = itexmo($_POST['contact'], $message, "TR-TRICY982682_IDL8E");
		if ($result == ""){
		echo "iTexMo: No response from server!!!
		Please check the METHOD used (CURL or CURL-LESS). If you are using CURL then try CURL-LESS and vice versa.	
		Please CONTACT US for help. ";	
		}else if ($result == 0){
		echo "Message Sent!";
		}
		else{	
		echo "Error Num ". $result . " was encountered!";
		}
}


function itexmo($number,$message,$apicode){
	$ch = curl_init();
	$itexmo = array('1' => $number, '2' => $message, '3' => $apicode);
	curl_setopt($ch, CURLOPT_URL,"https://www.itexmo.com/php_api/api.php");
	curl_setopt($ch, CURLOPT_POST, 1);
	 curl_setopt($ch, CURLOPT_POSTFIELDS, 
	          http_build_query($itexmo));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	return curl_exec ($ch);
	curl_close ($ch);
}

?>
