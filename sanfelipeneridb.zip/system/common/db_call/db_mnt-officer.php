<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'add_officer'){
	// INSERT TO TODA OFFICER
	$stmt = $db->prepare("INSERT INTO toda_officer (tricycle_id, position, date_created, created_by, status) VALUES (?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;

	$stmt->bindParam(1, $_POST['member']);
	$stmt->bindParam(2, $_POST['position']);
	$stmt->bindParam(3, date("Y-m-d H:i:s"));
	$stmt->bindParam(4, $default_created);
	$stmt->bindParam(5, $stat);
	$stmt->execute();

} else if($action == 'view_officer'){
	$stmt = $db->prepare('SELECT * FROM toda_officer o JOIN tricycle t ON
		t.tricycle_id = o.tricycle_id JOIN toda_name tn ON t.toda_id = tn.toda_id 
		JOIN member m ON m.member_id = t.member_id
		WHERE o.status = 1');
	$stmt->execute();

	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'] ?></td>
			<td><?php echo $row['contact']; ?></td>
			<td><?php echo $row['position'] ?></td>
			<td>
				<div class="col-xs-5"><?php echo $row['toda_name'] ?></div>
				<div class="col-xs-5" 
					style="background-color: <?php echo $row['toda_color']; ?>">
					&nbsp;
				</div>
			</td>
			<td><?php echo $row['plate_no'] ?></td>
			<td>
				<button class="btn btn-xs btn-info officer-edit" data-id="<?php echo $row['officer_id'] ?>"> Update
				</button>
				<button class="btn btn-xs btn-danger officer-delete" data-id="<?php echo $row['officer_id'] ?>"> Delete
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'get_officer'){
	$stmt = $db->prepare('SELECT * FROM toda_officer WHERE officer_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'update_officer'){
	$stmt = $db->prepare("UPDATE toda_officer SET tricycle_id=?, position=? WHERE officer_id = ?");
	$stmt->bindParam(1, $_POST['member']);
	$stmt->bindParam(2, $_POST['position']);
	$stmt->bindParam(3, $_POST['id']);
	
	$stmt->execute();
} else if($action == 'delete_officer'){
	$delete = 0;
	$stmt1 = $db->prepare("UPDATE toda_officer SET status = ? WHERE officer_id = ?");
	$stmt1->bindParam(1, $delete);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("INSERT INTO archive (id, table_name, deleted_by, date_created, status) VALUES (?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;
	$table = 'toda_officer';

	$stmt->bindParam(1, $_POST['id']);
	$stmt->bindParam(2, $table);
	$stmt->bindParam(3, $_POST['deleted_by']);
	$stmt->bindParam(4, date("Y-m-d H:i:s"));
	$stmt->bindParam(5, $stat);
	$stmt->execute();
} else if($action == 'get_member'){
	$stmt = $db->prepare('SELECT * FROM member m JOIN tricycle t 
		ON m.member_id = t.member_id JOIN toda_name tn 
		ON t.toda_id = tn.toda_id WHERE m.status = 1 
		AND availability = "no" AND member_status = "Active"');
	$stmt->execute();

	while($row = $stmt->fetch()){
		?>
		<option value="<?php echo $row['tricycle_id']; ?>">
			<?php 
			echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'].' | '.$row['toda_name'];
			?>
		</option>
		<?php
	}
}

?>