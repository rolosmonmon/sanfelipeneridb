<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'view_archive_toda'){
	$stmt = $db->prepare('SELECT * FROM archive a JOIN toda_name t 
		ON a.id=t.toda_id JOIN user_admin u on a.deleted_by = u.user_id 
		WHERE a.status = 1 AND table_name = "toda_name"');
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		$stmt->bindParam(1, $_POST['id']);
		?>
		<tr>
			<td><?php echo $row['toda_name'] ?></td>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'] ?></td>
			<td><?php echo $row['date_created'] ?></td>
			<td>
				<button class="btn btn-xs btn-success archive-restore-toda" data-id="<?php echo $row['id']; ?>" data-restore-id="<?php echo $row['archive_id'] ?>"> Restore
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'restore_archive_toda'){

	$restore = 1;
	$stmt1 = $db->prepare("UPDATE toda_name SET status = ? WHERE toda_id = ?");
	$stmt1->bindParam(1, $restore);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("UPDATE archive SET status=?, restored_by=? WHERE archive_id=?");
	$stat = 0;
	$table = 'toda_name';

	$stmt->bindParam(1, $stat);
	$stmt->bindParam(2, $_POST['restored_by']);
	$stmt->bindParam(3, $_POST['restore_id']);
	$stmt->execute();

} else if($action == 'view_archive_officer'){
	$stmt = $db->prepare('SELECT *, 
		CONCAT(m.last_name,", ",m.first_name," ",m.middle_name) AS member_name, 
		CONCAT(u.last_name,", ",u.first_name," ",u.middle_name) AS deleted_name
		FROM archive a JOIN toda_officer o ON a.id=o.officer_id 
		JOIN tricycle t ON t.tricycle_id = o.tricycle_id
		JOIN member m ON t.member_id=m.member_id
		JOIN user_admin u on a.deleted_by = u.user_id 
		WHERE a.status = 1 AND table_name = "toda_officer"');
	$stmt->execute();
	while($row = $stmt->fetch()){
		// print_r($row);
		?>
		<tr>
			<td><?php echo $row['member_name'] ?></td>
			<td><?php echo $row['deleted_name'] ?></td>
			<td><?php echo $row['date_created'] ?></td>
			<td>
				<button class="btn btn-xs btn-success archive-restore-officer" data-id="<?php echo $row['id']; ?>" data-restore-id="<?php echo $row['archive_id'] ?>"> Restore
				</button>
			</td>
		</tr>
		<?php
	}
} else if($action == 'restore_archive_officer'){

	$restore = 1;
	$stmt1 = $db->prepare("UPDATE toda_officer SET status = ? WHERE officer_id = ?");
	$stmt1->bindParam(1, $restore);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("UPDATE archive SET status=?, restored_by=? WHERE archive_id=?");
	$stat = 0;
	$table = 'toda_name';

	$stmt->bindParam(1, $stat);
	$stmt->bindParam(2, $_POST['restored_by']);
	$stmt->bindParam(3, $_POST['restore_id']);
	$stmt->execute();

} else if($action == 'view_archive_enforcer'){
	$stmt = $db->prepare('SELECT *, 
		CONCAT(e.last_name,", ",e.first_name," ",e.middle_name) AS enforcer_name, 
		CONCAT(u.last_name,", ",u.first_name," ",u.middle_name) AS deleted_name
		FROM archive a JOIN enforcer e ON a.id=e.enforcer_id
		JOIN user_admin u on a.deleted_by = u.user_id 
		WHERE a.status = 1 AND table_name = "enforcer"');
	$stmt->execute();
	while($row = $stmt->fetch()){
		// print_r($row);
		?>
		<tr>
			<td><?php echo $row['enforcer_name'] ?></td>
			<td><?php echo $row['deleted_name'] ?></td>
			<td><?php echo $row['date_created'] ?></td>
			<td>
				<button class="btn btn-xs btn-success archive-restore-enforcer" data-id="<?php echo $row['id']; ?>" data-restore-id="<?php echo $row['archive_id'] ?>"> Restore
				</button>
			</td>
		</tr>
		<?php
	}
} else if($action == 'restore_archive_enforcer'){

	$restore = 1;
	$stmt1 = $db->prepare("UPDATE enforcer SET status = ? WHERE enforcer_id = ?");
	$stmt1->bindParam(1, $restore);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("UPDATE archive SET status=?, restored_by=? WHERE archive_id=?");
	$stat = 0;
	$table = 'toda_name';

	$stmt->bindParam(1, $stat);
	$stmt->bindParam(2, $_POST['restored_by']);
	$stmt->bindParam(3, $_POST['restore_id']);
	$stmt->execute();

} else if($action == 'view_archive_user'){
	$stmt = $db->prepare('SELECT *,
		CONCAT(u.last_name,", ",u.first_name," ",u.middle_name) AS admin_name,
        CONCAT(d.last_name,", ",d.first_name," ",d.middle_name) AS deleted_name
		FROM archive a JOIN user_admin u ON a.id=u.user_id 
        JOIN user_admin d ON d.user_id=a.deleted_by 
        WHERE a.status = 1 and table_name = "user_admin"');
	$stmt->execute();
	while($row = $stmt->fetch()){
		// print_r($row);
		?>
		<tr>
			<td><?php echo $row['admin_name'] ?></td>
			<td><?php echo $row['deleted_name'] ?></td>
			<td><?php echo $row['date_created'] ?></td>
			<td>
				<button class="btn btn-xs btn-success archive-restore-user" data-id="<?php echo $row['id']; ?>" data-restore-id="<?php echo $row['archive_id'] ?>"> Restore
				</button>
			</td>
		</tr>
		<?php
	}
} else if($action == 'restore_archive_user'){

	$restore = 1;
	$stmt1 = $db->prepare("UPDATE user_admin SET status = ? WHERE user_id = ?");
	$stmt1->bindParam(1, $restore);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("UPDATE archive SET status=?, restored_by=? WHERE archive_id=?");
	$stat = 0;
	$table = 'toda_name';

	$stmt->bindParam(1, $stat);
	$stmt->bindParam(2, $_POST['restored_by']);
	$stmt->bindParam(3, $_POST['restore_id']);
	$stmt->execute();

}

?>