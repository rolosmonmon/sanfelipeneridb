<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'view_tricycle'){
	$stmt = $db->prepare('SELECT * FROM tricycle t JOIN toda_name tn 
		ON t.toda_id = tn.toda_id JOIN member m ON m.member_id = t.member_id
		WHERE t.status = 1');
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['brand']; ?></td>
			<td><?php echo $row['plate_no'] ?></td>
			<td><?php echo $row['motor_no'] ?></td>
			<td><?php echo $row['chassis_no'] ?></td>
			<td>
				<div class="col-xs-5"><?php echo $row['toda_name'] ?></div>
				<div class="col-xs-5" 
					style="background-color: <?php echo $row['toda_color']; ?>">
					&nbsp;
				</div>
			</td>
			<td><?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name'] ?></td>
			<!-- <td>
				<button class="btn btn-xs btn-<?php //echo $btn; ?> tricycle-status" data-id="<?php //echo $row['tricycle_id'] ?>"> <?php //echo $row['tricycle_status'] ?>
				</button>
			</td> -->
			<td>
				<button class="btn bg-navy btn-xs change-ownership" data-id="<?php echo $row['tricycle_id'] ?>"> Transfer Contract 
				</button>
				<button class="btn btn-xs btn-default see-history-tricycle" data-id="<?php echo $row['tricycle_id'] ?>"> <i class="fa fa-fw fa-history"></i>
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'change_owner'){
	// GET THE ORIGINAL OWNER
	$stmt1 = $db->prepare('SELECT member_id FROM tricycle WHERE tricycle_id=?');
	$stmt1->bindParam(1, $_POST['id']);
	$stmt1->execute();
	$row = $stmt1->fetch();

	$old_mem_id = $row['member_id'];

	// INSERT TO CHANGE OF OWNERSHIP
	$stmt = $db->prepare("INSERT INTO change_ownership (regfee, mch, petition, confirm, 
		inspect, superv, others, total, payment_date, member_id_from, member_id_to,
		date_created, created_by, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;
	$total = $_POST['regfee'] + $_POST['mch'] + $_POST['petition'] + $_POST['confirm'] + 
			$_POST['inspect'] + $_POST['superv'] + $_POST['others'];
	$stmt->bindParam(1, $_POST['regfee']);
	$stmt->bindParam(2, $_POST['mch']);
	$stmt->bindParam(3, $_POST['petition']);
	$stmt->bindParam(4, $_POST['confirm']);
	$stmt->bindParam(5, $_POST['inspect']);
	$stmt->bindParam(6, $_POST['superv']);
	$stmt->bindParam(7, $_POST['others']);
	$stmt->bindParam(8, $total);
	$stmt->bindParam(9, $_POST['payment-date']);
	$stmt->bindParam(10, $old_mem_id);
	$stmt->bindParam(11, $_POST['member']);
	$stmt->bindParam(12, date("Y-m-d H:i:s"));
	$stmt->bindParam(13, $default_created);
	$stmt->bindParam(14, $stat);
	$stmt->execute();

	// SET OLD MEMBER INACTIVE
	$mem_stat = 'Inactive';
	$stmt2 = $db->prepare("UPDATE member SET member_status = ? WHERE member_id = ?");
	$stmt2->bindParam(1, $mem_stat);
	$stmt2->bindParam(2, $old_mem_id);
	$stmt2->execute();

	// SET NEW MEMBER AVAILABILITY TO NO
	$av_stat = 'no';
	$stmt3 = $db->prepare("UPDATE member SET availability = ? WHERE member_id = ?");
	$stmt3->bindParam(1, $av_stat);
	$stmt3->bindParam(2, $_POST['member']);
	$stmt3->execute();

	// UPDATE TRICYCLE
	$av_stat = 'no';
	$stmt2 = $db->prepare("UPDATE tricycle SET member_id = ? WHERE tricycle_id = ?");
	$stmt2->bindParam(1, $_POST['member']);
	$stmt2->bindParam(2, $_POST['id']);
	$stmt2->execute();
} else if($action == 'get_member'){
	$stmt = $db->prepare('SELECT * FROM member WHERE status = 1 
		AND availability = "yes" AND member_status = "Active"');
	// $stmt->bindParam(1, $_POST['id']);
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		?>
		<option value="<?php echo $row['member_id']; ?>">
			<?php echo $row['last_name'].', '.$row['first_name'].' '.$row['middle_name']?>
		</option>
		<?php
	}
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'view_history'){
	$stmt = $db->prepare('SELECT *, 
		CONCAT(m_fr.last_name, ", ", m_fr.first_name, " ", m_fr.middle_name) as name_from,
		CONCAT(m_to.last_name, ", ", m_to.first_name, " ", m_to.middle_name) as name_to
		FROM change_ownership c 
		JOIN member m_fr ON m_fr.member_id = c.member_id_from 
		JOIN member m_to ON m_to.member_id = c.member_id_to 
		JOIN tricycle t ON t.member_id = m_to.member_id
		WHERE c.status = 1 AND t.tricycle_id=?');
	$stmt->bindParam(1, $_POST['tricycle_id']);
	$stmt->execute();

	while($row = $stmt->fetch()){
		// print_r($row);
		?>
			<tr>
				<td><?php echo $row['name_from']; ?></td>
				<td><?php echo $row['name_to']; ?></td>
				<td><?php echo $row['payment_date'] ?></td>
				<td>
					<button class="btn bg-default btn-xs download-invoice" data-id="<?php echo $row['change_id'] ?>"> Print Receipt
					</button>
				</td>
			</tr>
		<?php
	}
}

?>