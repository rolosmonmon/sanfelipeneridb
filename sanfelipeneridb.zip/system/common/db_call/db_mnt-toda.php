<?php
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'add_toda'){
	$stmt = $db->prepare("INSERT INTO toda_name (toda_name, toda_color, date_created, created_by, status) VALUES (?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;

	$stmt->bindParam(1, $_POST['toda-name']);
	$stmt->bindParam(2, $_POST['toda-color']);
	$stmt->bindParam(3, date("Y-m-d H:i:s"));
	$stmt->bindParam(4, $default_created);
	$stmt->bindParam(5, $stat);
	$stmt->execute();
} else if($action == 'view_toda'){
	$stmt = $db->prepare('SELECT * FROM toda_name WHERE status = 1');
	$stmt->execute();
	// print_r($stmt->fetch());
	while($row = $stmt->fetch()){
		?>
		<tr>
			<td><?php echo $row['toda_name'] ?></td>
			<td> <div style="background-color: <?php echo $row['toda_color'] ?>">&nbsp;</div></td>
			<td>
				<button class="btn btn-xs btn-info toda-edit" data-id="<?php echo $row['toda_id'] ?>"> Update
				</button>
				<button class="btn btn-xs btn-danger toda-delete" data-id="<?php echo $row['toda_id'] ?>"> Delete
				</button>
			</td>
		</tr>
		<?php
	}

} else if($action == 'get_toda'){
	$stmt = $db->prepare('SELECT * FROM toda_name WHERE toda_id=?');
	$stmt->bindParam(1, $_POST['id']);
	$stmt->execute();

	print_r(json_encode($stmt->fetch(), true));
} else if($action == 'update_toda'){
	$stmt1 = $db->prepare("UPDATE toda_name SET toda_name=?, toda_color=? WHERE toda_id = ?");
	$stmt1->bindParam(1, $_POST['toda-name']);
	$stmt1->bindParam(2, $_POST['toda-color']);
	$stmt1->bindParam(3, $_POST['id']);
	
	$stmt1->execute();
	// print_r($_POST);
	// print_r(json_encode($stmt->fetch(), true));
} else if($action == 'delete_toda'){
	$delete = 0;
	$stmt1 = $db->prepare("UPDATE toda_name SET status = ? WHERE toda_id = ?");
	$stmt1->bindParam(1, $delete);
	$stmt1->bindParam(2, $_POST['id']);
	$stmt1->execute();

	$stmt = $db->prepare("INSERT INTO archive (id, table_name, deleted_by, date_created, status) VALUES (?,?,?,?,?)");
	$default_created = 1;
	$stat = 1;
	$table = 'toda_name';

	$stmt->bindParam(1, $_POST['id']);
	$stmt->bindParam(2, $table);
	$stmt->bindParam(3, $_POST['deleted_by']);
	$stmt->bindParam(4, date("Y-m-d H:i:s"));
	$stmt->bindParam(5, $stat);
	$stmt->execute();

}

?>