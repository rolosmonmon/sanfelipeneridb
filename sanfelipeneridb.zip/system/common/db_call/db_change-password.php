<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";

$action = $_GET['action'];
$db = new PDO("mysql:host=$servername;dbname=toda_db", $username, $password);

if($action == 'change_password'){
	$stmt = $db->prepare('SELECT * FROM user_admin WHERE username=? and password=?');
	$stmt->bindParam(1, $_POST['username']);
	$stmt->bindParam(2, $_POST['old']);
	$stmt->execute();
	$row = $stmt->fetch();

	if(empty($row)){
		echo 'error';
	} else {
		$stmt1 = $db->prepare("UPDATE user_admin SET password=? WHERE username = ?");
		$stmt1->bindParam(1, $_POST['new']);
		$stmt1->bindParam(2, $_POST['username']);
		$stmt1->execute();
		
		session_destroy();
		session_unset();
		echo 'ok';
	}
}
?>

