$(function () {
    viewUser();
})
function viewUser() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-user_admin.php?action=view_user",
		// data: pass_data,
		success: function(msg){
			$('#view_user tbody').html(msg);
			$('#view_user').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    addUser();
		    editUser();
		    deleteUser();

		}
	})
}

function addUser() {
	$('#user_add').unbind('click').bind('click', function() {
		$('#modal-add-user').modal('show');
		var default_field = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'password'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#user-'+e).val('');
		  $('#user-'+e).parent().removeClass('has-error');
		});
		$('.contact-validation').html('');
		
		$('#user-birthday').datepicker();

		$('#user-birthday').parent().parent().removeClass('has-error');
		$('#user-birthday').parent().parent().find('small').html('');

		$('#user-contact').inputmask('99999999999');

	});

	$('#save-add-user').unbind('click').bind('click', function() {
		var default_save = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'gender', 'position', 'password'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#user-'+e).parent().removeClass('has-error');

			if($('#user-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#user-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#user-'+e).val().trim();
			}
		});
		$('.contact-validation').html('');
		var contact = $('#user-contact').val();
		if(contact.replace('_', '').length != 11 && contact.replace('_', '').length != ''){
			error = true;
			$('#user-contact').parent().addClass('has-error');
			$('.contact-validation').html('Contact must be 11 digits.');
		}

		// GET MAX DATE
		$('#user-birthday').parent().parent().removeClass('has-error');
		$('#user-birthday').parent().parent().find('small').html('');
		
		var date_now = new Date().toJSON().slice(0,10).replace(/-/g,'/');
		var sliceDate = date_now.split('/');
		var yearsAgo18 = sliceDate[0]-18;
		var max_date = new Date(sliceDate[1]+'/'+sliceDate[2]+'/'+yearsAgo18);
		var birthdate = new Date($('#user-birthday').val());
		if(max_date < birthdate){
			error = true
			$('#user-birthday').parent().parent().addClass('has-error');
			$('#user-birthday').parent().parent().find('small').addClass('c-red').html('User must be 18 years old and above.');
		}	

		pass_data += '&created_by='+$('.user-id').attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-user_admin.php?action=add_user",
				data: pass_data,
				success: function(msg){
					$('#view_user').DataTable().destroy();
					$('.modal').modal('hide');
					viewUser();
				}
			})
		}
	});
}

function editUser() {
	$('.user-edit').unbind('click').bind('click', function() {
		
		var default_field = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'password'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#user-edit-'+e).parent().removeClass('has-error');
		});
		$('.contact-validation').html('');
		$('#user-edit-birthday').datepicker();
		$('#user-edit-contact').inputmask('99999999999');

		$('#user-edit-birthday').parent().parent().removeClass('has-error');
		$('#user-edit-birthday').parent().parent().find('small').html('');

		// POPULATE DATA
		var this_id = $(this).attr('data-id');
		$('#save-edit-user').attr('data-id', this_id);
		$.ajax({
			type: "POST",
			url: "common/db_call/db_mnt-user_admin.php?action=get_user",
			data: 'id='+this_id,
			success: function(msg){
				var data = JSON.parse(msg);
				$('#modal-edit-user').modal('show');
				$('#user-edit-first-name').val(data['first_name']);
				$('#user-edit-middle-name').val(data['middle_name']);
				$('#user-edit-last-name').val(data['last_name']);
				$('#user-edit-contact').val(data['contact']);
				$('#user-edit-birthday').val(data['birthday']);
				$('#user-edit-gender').val(data['gender']);
				$('#user-edit-position').val(data['position']);
			}
		})


	});

	$('#save-edit-user').unbind('click').bind('click', function() {
		var default_save = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'gender', 'position'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#user-edit-'+e).parent().removeClass('has-error');

			if($('#user-edit-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#user-edit-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#user-edit-'+e).val().trim();
			}
		});
		$('.contact-validation').html('');
		var contact = $('#user-edit-contact').val();
		if(contact.replace('_', '').length != 11 && contact.replace('_', '').length != ''){
			error = true;
			$('#user-edit-contact').parent().addClass('has-error');
			$('.contact-validation').html('Contact must be 11 digits.');
		}

		// GET MAX DATE
		$('#user-edit-birthday').parent().parent().removeClass('has-error');
		$('#user-edit-birthday').parent().parent().find('small').html('');
		
		var date_now = new Date().toJSON().slice(0,10).replace(/-/g,'/');
		var sliceDate = date_now.split('/');
		var yearsAgo18 = sliceDate[0]-18;
		var max_date = new Date(sliceDate[1]+'/'+sliceDate[2]+'/'+yearsAgo18);
		var birthdate = new Date($('#user-edit-birthday').val());
		if(max_date < birthdate){
			error = true
			$('#user-edit-birthday').parent().parent().addClass('has-error');
			$('#user-edit-birthday').parent().parent().find('small').addClass('c-red').html('User must be 18 years old and above.');
		}	

		pass_data += '&id='+$(this).attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-user_admin.php?action=update_user",
				data: pass_data,
				success: function(msg){
					$('#view_user').DataTable().destroy();
					$('.modal').modal('hide');
					viewUser();
				}
			})
		}
	});
}

function deleteUser() {
	$('.user-delete').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		$('#save-delete-user').attr('data-id', this_id);
		$('#modal-delete-user').modal('show');
	});

	$('#save-delete-user').unbind('click').bind('click', function(){
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-user_admin.php?action=delete_user",
				data: 'id='+$(this).attr('data-id')+'&deleted_by='+$('.user-id').attr('data-id'),
				success: function(msg){
					$('#view_user').DataTable().destroy();
					$('.modal').modal('hide');
					viewUser();
				}
			})
	})
}