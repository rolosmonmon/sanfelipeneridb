$(function () {
    viewOfficer();
})
function viewOfficer() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-officer.php?action=view_officer",
		success: function(msg){
			$('#view_officer tbody').html(msg);
			$('#view_officer').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    addOfficer();
		    editOfficer();
		    deleteOfficer();

		}
	})
}

function addOfficer() {
	$('#officer_add').unbind('click').bind('click', function() {
		$('#modal-add-officer').modal('show');
		var default_field = ['position'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#officer-'+e).val('');
		  $('#officer-'+e).parent().removeClass('has-error');
		});

		$('.select2').select2();
		getMember();
	});

	$('#save-add-officer').unbind('click').bind('click', function() {
		var default_save = ['position', 'member'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#officer-'+e).parent().removeClass('has-error');

			if($('#officer-'+e).val() != null){
				if($('#officer-'+e).val().trim() == ''){
					error = true;
					$('#officer-'+e).parent().addClass('has-error');
				} else {
					pass_data +='&'+e+'='+$('#officer-'+e).val().trim();
				}
			} else {
				error = true;
				$('#officer-'+e).parent().addClass('has-error');
			}
		});

		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-officer.php?action=add_officer",
				data: pass_data,
				success: function(msg){
					$('#view_officer').DataTable().destroy();
					$('.modal').modal('hide');
					viewOfficer();
				}
			})
		}
	});
}

function editOfficer() {
	$('.officer-edit').unbind('click').bind('click', function() {
		
		var default_field = ['position', 'member'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#officer-edit-'+e).parent().removeClass('has-error');
		});

		$('.select2').select2();
		// POPULATE DATA
		var this_id = $(this).attr('data-id');
		$('#save-edit-officer').attr('data-id', this_id);
		$.ajax({
			type: "POST",
			url: "common/db_call/db_mnt-officer.php?action=get_officer",
			data: 'id='+this_id,
			success: function(msg){
				var data = JSON.parse(msg);

				getMember(data['tricycle_id']);

				$('#modal-edit-officer').modal('show');
				$('#officer-edit-position').val(data['position']);
			}
		})


	});

	$('#save-edit-officer').unbind('click').bind('click', function() {
		var default_save = ['position', 'member'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#officer-edit-'+e).parent().removeClass('has-error');

			if($('#officer-edit-'+e).val().trim() == ''){
				error = true;
				$('#officer-edit-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#officer-edit-'+e).val().trim();
			}
		});
		pass_data += '&id='+$(this).attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-officer.php?action=update_officer",
				data: pass_data,
				success: function(msg){
					$('#view_officer').DataTable().destroy();
					$('.modal').modal('hide');
					viewOfficer();
				}
			})
		}
	});
}

function deleteOfficer() {
	$('.officer-delete').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		$('#save-delete-officer').attr('data-id', this_id);
		$('#modal-delete-officer').modal('show');
	});

	$('#save-delete-officer').unbind('click').bind('click', function(){
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-officer.php?action=delete_officer",
				data: 'id='+$(this).attr('data-id')+'&deleted_by='+$('.user-id').attr('data-id'),
				success: function(msg){
					$('#view_officer').DataTable().destroy();
					$('.modal').modal('hide');
					viewOfficer();
				}
			})
	})
}

function getMember(action = 'add') {
	if(action == 'add'){
		var btn = '';
	} else {
		var btn = '-edit';
	}
	// THIS IS FOR LOADING OF SELECT TODA NAME
	$.ajax({
		type: "POST",
		url: "common/db_call/db_mnt-officer.php?action=get_member",
		success: function(msg){
			// OPTIONS
			$('#officer'+btn+'-member').html(msg);
			
			if(action != 'add'){
				$('#officer-edit-member').val(action);
			}
		}
	})
}