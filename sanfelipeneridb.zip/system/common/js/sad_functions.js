$(function () {
    downloadDatabase();
    viewPaymentClient();
    showMonthlyReport();
})


function downloadDatabase() {

	//~~ #2 DOWNLOAD DATABASE BACKUP
	$('#download-database').unbind('click').bind('click', function() {
		$.ajax({
				type: "POST",
				url: "common/db_call/db_SAD.php?action=download_database",

				success: function(msg){
					alert("Downloading the backup database is done!");
					window.open('common/db_call/'+msg);


				}
			})
	});
	// 
}

function viewPaymentClient() {
	$('#view-client-payment').DataTable().destroy();
    $.ajax({
		type: "GET",
		url: "common/db_call/db_SAD.php?action=view_clients_payment",
		// data: pass_data,
		success: function(msg){
			$('#view-client-payment tbody').html(msg);
			$('#view-client-payment').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });

			downloadReceipt();
		}
	})
}

function showMonthlyReport(){
	$('#monthly-report').unbind('click').bind('click', function() {
		$('#modal-monthly-report').modal('show');

	});

	$('#show-monthly-report-button').unbind('click').bind('click', function() {
		var year = $('#select-year').val();
		var link = '&year='+year;
		$.ajax({
			type: "GET",
			url: "common/db_call/db_SAD.php?action=view_yearly_report"+link,
			// data: pass_data,
			success: function(msg){
				var msg = JSON.parse(msg);
				$('#original-contract').html('PHP '+msg['original-contract']);
				$('#valid-id').html('PHP '+msg['valid-id']);
				$('#official-receipt').html('PHP '+msg['official-receipt']);
				$('#transfer-fee').html('PHP '+msg['transfer-fee']);
				$('#contract-fee').html('PHP '+msg['contract-fee']);
				$('#govt-requirements').html('PHP '+msg['govt-requirements']);
				$('#others').html('PHP '+msg['others']);
				$('#total-sales').html('PHP '+msg['total-sales']);
				// console.log(JSON.parse(msg));
			}
		})
	});
}

function downloadReceipt() {
	$('.print-receipt').unbind('click').bind('click', function() {
		// 
		$.ajax({
			type: "GET",
			url: "common/db_call/db_SAD.php?action=download_receipt&change_id="+$(this).attr('data-id'),
			// data: pass_data,
			success: function(msg){
				var msg = JSON.parse(msg);
				$('#print-original-contract').html(msg['original-contract']);
				$('#print-valid-id').html(msg['valid-id']);
				$('#print-official-receipt').html(msg['official-receipt']);
				$('#print-transfer-fee').html(msg['transfer-fee']);
				$('#print-contract-fee').html(msg['contract-fee']);
				$('#print-govt-requirements').html(msg['govt-requirements']);
				$('#print-others').html(msg['others']);
				$('#print-total-sales').html(msg['total-sales']);
				
				var divToPrint = $('#receipt-client');
				var popupWin = window.open('', '_blank', 'width=800,height=500');
				popupWin.document.open();
				popupWin.document.write('<html><style type="text/css">@page { margin: 0; }</style><body onload="window.print()">' + divToPrint.html() + '</html>');
				popupWin.document.close();
			}
		})
	});
	
}