$(function () {
    viewArchiveToda();

    $('[href="#tab_user_admin"]').unbind('click').bind('click', function() {
    	$('#view_archive_user').DataTable().destroy();
    	viewArchiveUser();
    });
    $('[href="#tab_officer"]').unbind('click').bind('click', function() {
    	$('#view_archive_officer').DataTable().destroy();
    	viewArchiveOfficer();
    });
    $('[href="#tab_enforcer"]').unbind('click').bind('click', function() {
    	$('#view_archive_enforcer').DataTable().destroy();
    	viewArchiveEnforcer();
    });
    $('[href="#tab_toda_name"]').unbind('click').bind('click', function() {
    	$('#view_archive_toda').DataTable().destroy();
    	viewArchiveToda();
    });
})

// TODA NAME
function viewArchiveToda() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-archive.php?action=view_archive_toda",
		// data: pass_data,
		success: function(msg){
			$('#view_archive_toda tbody').html(msg);
			$('#view_archive_toda').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    restoreArchiveToda();

		}
	})
}
function restoreArchiveToda() {
	$('.archive-restore-toda').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		var this_restore_id = $(this).attr('data-restore-id');
		$('#save-restore-toda').attr('data-id', this_id);
		$('#save-restore-toda').attr('data-restore-id', this_restore_id);
		$('#modal-restore-toda').modal('show');
	});

	$('#save-restore-toda').unbind('click').bind('click', function(){
		var pass_data = 'restore_id='+$(this).attr('data-restore-id')+'&id='+$(this).attr('data-id')+'&restored_by='+$('.user-id').attr('data-id');
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-archive.php?action=restore_archive_toda",
				data: pass_data,
				success: function(msg){
					$('#view_archive_toda').DataTable().destroy();
					$('.modal').modal('hide');
					viewArchiveToda();
				}
			})
	})
}

// USER ADMIN
function viewArchiveUser() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-archive.php?action=view_archive_user",
		// data: pass_data,
		success: function(msg){
			$('#view_archive_user tbody').html(msg);
			$('#view_archive_user').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    restoreArchiveUser();

		}
	})
}
function restoreArchiveUser() {
	$('.archive-restore-user').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		var this_restore_id = $(this).attr('data-restore-id');
		$('#save-restore-user').attr('data-id', this_id);
		$('#save-restore-user').attr('data-restore-id', this_restore_id);
		$('#modal-restore-user').modal('show');
	});

	$('#save-restore-user').unbind('click').bind('click', function(){
		var pass_data = 'restore_id='+$(this).attr('data-restore-id')+'&id='+$(this).attr('data-id')+'&restored_by='+$('.user-id').attr('data-id');
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-archive.php?action=restore_archive_user",
				data: pass_data,
				success: function(msg){
					$('#view_archive_user').DataTable().destroy();
					$('.modal').modal('hide');
					viewArchiveUser();
				}
			})
	})
}

// OFFICER
function viewArchiveOfficer() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-archive.php?action=view_archive_officer",
		// data: pass_data,
		success: function(msg){
			$('#view_archive_officer tbody').html(msg);
			$('#view_archive_officer').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    restoreArchiveOfficer();

		}
	})
}
function restoreArchiveOfficer() {
	$('.archive-restore-officer').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		var this_restore_id = $(this).attr('data-restore-id');
		$('#save-restore-officer').attr('data-id', this_id);
		$('#save-restore-officer').attr('data-restore-id', this_restore_id);
		$('#modal-restore-officer').modal('show');
	});

	$('#save-restore-officer').unbind('click').bind('click', function(){
		var pass_data = 'restore_id='+$(this).attr('data-restore-id')+'&id='+$(this).attr('data-id')+'&restored_by='+$('.user-id').attr('data-id');
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-archive.php?action=restore_archive_officer",
				data: pass_data,
				success: function(msg){
					$('#view_archive_officer').DataTable().destroy();
					$('.modal').modal('hide');
					viewArchiveOfficer();
				}
			})
	})
}

// ENFORCER
function viewArchiveEnforcer() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-archive.php?action=view_archive_enforcer",
		// data: pass_daenforcer		
		success: function(msg){
			$('#view_archive_enforcer tbody').html(msg);
			$('#view_archive_enforcer').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    restoreArchiveEnforcer();

		}
	})
}
function restoreArchiveEnforcer() {
	$('.archive-restore-enforcer').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		var this_restore_id = $(this).attr('data-restore-id');
		$('#save-restore-enforcer').attr('data-id', this_id);
		$('#save-restore-enforcer').attr('data-restore-id', this_restore_id);
		$('#modal-restore-enforcer').modal('show');
	});

	$('#save-restore-enforcer').unbind('click').bind('click', function(){
		var pass_data = 'restore_id='+$(this).attr('data-restore-id')+'&id='+$(this).attr('data-id')+'&restored_by='+$('.user-id').attr('data-id');
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-archive.php?action=restore_archive_enforcer",
				data: pass_data,
				success: function(msg){
					$('#view_archive_enforcer').DataTable().destroy();
					$('.modal').modal('hide');
					viewArchiveEnforcer();
				}
			})
	})
}