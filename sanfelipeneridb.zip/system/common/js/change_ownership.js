$(function () {
    viewTricycle();
})
function viewTricycle() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_trnsc-change_ownership.php?action=view_tricycle",
		// data: pass_data,
		success: function(msg){
			$('#view_all_tricycle tbody').html(msg);
			$('#view_all_tricycle').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
			
			changeOwnership();
			seeHistory();
		}
	})
}

function changeOwnership() {
	$('.change-ownership').unbind('click').bind('click', function() {
		$('#modal-change-ownership').modal('show');
		$('#save-change-ownership').attr('data-id', $(this).attr('data-id'));

		// DEFAULT
		$('#ch-own-payment-date').val('');
		$('#ch-own-payment-date').parent().removeClass('has-error');
		$('#ch-own-member').parent().removeClass('has-error');
		var fields_chkbx = ['regfee', 'mch', 'petition', 'confirm', 'inspect', 'superv'];
		fields_chkbx.forEach(function(e) {
			$('#ch-own-'+e).iCheck('uncheck');
		});
		// GET LIST OF MEMBER
		getMember();
	});

	$('#save-change-ownership').unbind('click').bind('click', function() {
		var fields_chkbx = ['regfee', 'mch', 'petition', 'confirm', 'inspect', 'superv'];
		var pass_data = '';
		var error = false;
		fields_chkbx.forEach(function(e) {
    		if($('#ch-own-'+e).is(":checked")){
    			pass_data += '&'+e+'='+$('#ch-own-'+e).val();
    		} else {
    			pass_data += '&'+e+'=0';
    		}
    	});

		// START VALIDATION
		if($('#ch-own-payment-date').val() == ''){
			$('#ch-own-payment-date').parent().addClass('has-error');
			error = true;
		}
		if($('#ch-own-member').val() == null){
			$('#ch-own-member').parent().addClass('has-error');
			error = true;
		}

		if(!error) {
			var loop_val = ['member', 'payment-date', 'others'];
			loop_val.forEach(function(e) {
	    		pass_data += '&'+e+'='+$('#ch-own-'+e).val();
	    	});

			$('#ch-own-payment-date').parent().removeClass('has-error');
			$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-change_ownership.php?action=change_owner",
				data: 'id='+$(this).attr('data-id')+pass_data,
				success: function(msg){
					$('#view_all_tricycle').DataTable().destroy();
					$('.modal').modal('hide');
					viewTricycle();
				}
			})
		}

	});


	// FORMATS
	$('#ch-own-payment-date').datepicker();
	//Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })
}

function seeHistory() {
	$('.see-history-tricycle').unbind('click').bind('click', function() {
		$('#modal-see-history').modal('show');
		// VIEW HISTORY
		$.ajax({
			type: "POST",
			url: "common/db_call/db_trnsc-change_ownership.php?action=view_history",
			data: 'tricycle_id='+$(this).attr('data-id'),
			success: function(msg){
				$('#view_history').DataTable().destroy();
				$('#view_history tbody').html(msg);
				$('#view_history').DataTable({
			      'paging'      : true,
			      'lengthChange': false,
			      'searching'   : true,
			      'ordering'    : true,
			      'info'        : true,
			      'autoWidth'   : false
			    });
			}
		})
	});
}

function getMember(action = 'add') {
	if(action == 'add'){
		var btn = '';
	} else {
		var btn = '-edit';
	}
	// THIS IS FOR LOADING OF SELECT TODA NAME
	$.ajax({
		type: "POST",
		url: "common/db_call/db_trnsc-change_ownership.php?action=get_member",
		success: function(msg){
			// OPTIONS
			$('#ch-own'+btn+'-member').html(msg);
			
			if(action != 'add'){
				$('#ch-own-edit-member').val(action);
			}
		}
	})
}