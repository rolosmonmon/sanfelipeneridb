$(function () {
    changePassword();

})

function changePassword() {
	$('#change-pass').unbind('click').bind('click', function() {
		var error = false;
		var pass_data = '';
		// REMOVE VALIDATION
		var list_pass = ['old', 'new', 'confirm'];
		list_pass.forEach(function(e) {
			$('#'+e+'-password').parent().removeClass('has-error');
			$('#'+e+'-password').parent().find('small').html('');
			if($('#'+e+'-password').val() == ''){
				error = true;
				$('#'+e+'-password').parent().addClass('has-error');
			}
			pass_data += '&'+e+'='+$('#'+e+'-password').val();
		});

		// MORE VALIDATION
		if($('#new-password').val() !== $('#confirm-password').val()){
			error = true;
			$('#confirm-password').parent().addClass('has-error');
			$('#confirm-password').parent().find('small').addClass('c-red').html('Confirm Password must be the same as the New Password');
		}

		// CHANGE PASSWORD
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_change-password.php?action=change_password",
				data: pass_data+'&username='+$('#username').val(),
				success: function(msg){
					if(msg == 'ok'){
						location.replace('../index.html');
					} else {
						alert('error');
					}
				}
			})
		}
	});
}