$(function () {
    viewTricycle();
})
function viewTricycle() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_trnsc-tricycle.php?action=view_tricycle",
		// data: pass_data,
		success: function(msg){
			$('#view_tricycle tbody').html(msg);
			$('#view_tricycle').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    addTricycle();
		    editTricycle();
		    deleteTricycle();

		    tricycleRegistration();
		    historyRegistration();
		}
	})
}
function historyRegistration() {
	$('.history-tricycle').unbind('click').bind('click', function() {
		var tri_id = $(this).attr('data-tri-id');

		$('#modal-tricycle-history').modal('show');
		$.ajax({
			type: "POST",
			url: "common/db_call/db_trnsc-tricycle.php?action=view_tricycle_registration",
			data: 'id='+tri_id,
			success: function(msg){
				$('#view_tricycle_registration').DataTable().destroy();
				$('#view_tricycle_registration tbody').html(msg);
				$('#view_tricycle_registration').DataTable({
			      'paging'      : true,
			      'lengthChange': true,
			      'searching'   : true,
			      'ordering'    : true,
			      'info'        : true,
			      'autoWidth'   : false
			    });
			}
		})
	});
}
function addTricycle() {
	$('#tricycle_add').unbind('click').bind('click', function() {
		$('.select2').select2()
		$('#modal-add-tricycle').modal('show');
		var default_field = ['brand', 'motor-no', 'plate-no', 'chassis-no'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#tricycle-'+e).val('');
		  $('#tricycle-'+e).parent().removeClass('has-error');
		});

		getToda();
		getMember();
	});

	$('#save-add-tricycle').unbind('click').bind('click', function() {
		var default_save = ['brand', 'motor-no', 'plate-no', 'chassis-no', 'toda-name', 'member'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#tricycle-'+e).parent().removeClass('has-error');

			if($('#tricycle-'+e).val() != null){
				if($('#tricycle-'+e).val().trim() == ''){
					error = true;
					$('#tricycle-'+e).parent().addClass('has-error');
				} else {
					pass_data +='&'+e+'='+$('#tricycle-'+e).val().trim();
				}
			} else {
				error = true;
				$('#tricycle-'+e).parent().addClass('has-error');
			}
		});

		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-tricycle.php?action=add_tricycle",
				data: pass_data,
				success: function(msg){
					$('#view_tricycle').DataTable().destroy();
					$('.modal').modal('hide');
					viewTricycle();
				}
			})
		}
	});
}

function editTricycle() {
	$('.tricycle-edit').unbind('click').bind('click', function() {
		
		var default_field = ['brand', 'motor-no', 'plate-no', 'chassis-no', 'toda-name'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#tricycle-edit-'+e).parent().removeClass('has-error');
		});

		// POPULATE DATA
		var this_id = $(this).attr('data-id');
		$('#save-edit-tricycle').attr('data-id', this_id);
		$.ajax({
			type: "POST",
			url: "common/db_call/db_trnsc-tricycle.php?action=get_tricycle",
			data: 'id='+this_id,
			success: function(msg){
				var data = JSON.parse(msg);

				getToda(data['toda_id']);

				$('#modal-edit-tricycle').modal('show');
				$('#tricycle-edit-brand').val(data['brand']);
				$('#tricycle-edit-motor-no').val(data['motor_no']);
				$('#tricycle-edit-plate-no').val(data['plate_no']);
				$('#tricycle-edit-chassis-no').val(data['chassis_no']);
				var full_name = data['last_name']+', '+data['first_name']+' '+data['middle_name'];
				$('#tricycle-edit-member').val(full_name);
				
			}
		})


	});

	$('#save-edit-tricycle').unbind('click').bind('click', function() {
		var default_save =  ['brand', 'motor-no', 'plate-no', 'chassis-no', 'toda-name'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#tricycle-edit-'+e).parent().removeClass('has-error');

			if($('#tricycle-edit-'+e).val().trim() == ''){
				error = true;
				$('#tricycle-edit-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#tricycle-edit-'+e).val().trim();
			}
		});
		pass_data += '&id='+$(this).attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-tricycle.php?action=update_tricycle",
				data: pass_data,
				success: function(msg){
					$('#view_tricycle').DataTable().destroy();
					$('.modal').modal('hide');
					viewTricycle();
				}
			})
		}
	});
}

function deleteTricycle() {
	$('.tricycle-delete').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		$('#save-delete-tricycle').attr('data-id', this_id);
		$('#save-delete-tricycle').attr('data-mem-id', $(this).attr('data-mem-id'));
		$('#modal-delete-tricycle').modal('show');
	});

	$('#save-delete-tricycle').unbind('click').bind('click', function(){
		$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-tricycle.php?action=delete_tricycle",
				data: 'id='+$(this).attr('data-id')+'&member_id='+$(this).attr('data-mem-id'),
				success: function(msg){
					$('#view_tricycle').DataTable().destroy();
					$('.modal').modal('hide');
					viewTricycle();
				}
			})
	})
}

function getToda(action = 'add') {
	if(action == 'add'){
		var btn = '';
	} else {
		var btn = '-edit';
	}
	// THIS IS FOR LOADING OF SELECT TODA NAME
	$.ajax({
		type: "POST",
		url: "common/db_call/db_trnsc-tricycle.php?action=get_toda",
		success: function(msg){
			// OPTIONS
			$('#tricycle'+btn+'-toda-name').html(msg);
			
			if(action != 'add'){
				$('#tricycle-edit-toda-name').val(action);
			}
		}
	})
}

function getMember(action = 'add') {
	if(action == 'add'){
		var btn = '';
	} else {
		var btn = '-edit';
	}
	// THIS IS FOR LOADING OF SELECT TODA NAME
	$.ajax({
		type: "POST",
		url: "common/db_call/db_trnsc-tricycle.php?action=get_member",
		success: function(msg){
			// OPTIONS
			$('#tricycle'+btn+'-member').html(msg);
			
			if(action != 'add'){
				$('#tricycle-edit-member').val(action);
			}
		}
	})
}

function tricycleRegistration() {
	var date_loop = ['payment-date', 'effective-date', 'expiration'];
	var check_fields = ['regfee', 'regsticker', 'confirm', 'inspect', 'superv', 'farerate', 'platesticker'];
	
	$('.tricycle-register').unbind('click').bind('click', function() {
		$('#save-pending-tricycle').attr('data-id', $(this).attr('data-id'));
		$('#save-pending-tricycle').attr('data-tri-id', $(this).attr('data-tri-id'));

		$('#modal-pending-tricycle').modal('show');

		$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-tricycle.php?action=view_pending_tricycle",
				data: 'id='+$(this).attr('data-id'),
				success: function(msg){
					var data = JSON.parse(msg);
					check_fields.forEach(function(e) {
						if(data[e] != 0 && data[e] != null){
							$('#reg-tri-'+e).iCheck('check');
						} else {
							$('#reg-tri-'+e).iCheck('uncheck');
						}
					});
					$('#reg-tri-others').val(data['others']);

					date_loop.forEach(function(e) {
					  $('#tricycle-'+e).val(data[e.replace('-', '_')]);
					});
				}
			})

		// FORMAT
		date_loop.forEach(function(e) {
			  $('#tricycle-'+e).datepicker();
			  $('#tricycle-'+e).parent().removeClass('has-error');
			});


			// SET EXPIRATION DATE
			$('#tricycle-effective-date').focusout(function() {
				var this_date = $('#tricycle-effective-date').val();
				var getYear = this_date.split('/');
				var next_year = parseInt(getYear[2]) +2;
				var expiration = getYear[0]+'/'+getYear[1]+'/'+next_year;
				console.log(next_year);
				var d = new Date(expiration);
 				d.setDate(d.getDate()-2);
 				var newMonth = d.getMonth()+1;
 				var newDay = d.getDate();
 				if(d.getMonth() < 10){
 					newMonth = '0'+newMonth;
 				}
 				if(d.getDate() < 10){
 					newDay = '0'+newDay;
 				}

 				var new_date = newMonth+'/'+newDay+'/'+d.getFullYear();
 				// console.log(new_date);
				$('#tricycle-expiration').val(new_date);
			})
	});

	//Flat red color scheme for iCheck
	    $('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
	      checkboxClass: 'icheckbox_flat-green',
	      radioClass   : 'iradio_flat-green'
	    });

	$('#save-pending-tricycle').unbind('click').bind('click', function() {
			var id = $(this).attr('data-id');
	    	var fields_chkbx = ['regfee', 'regsticker', 'confirm', 'inspect', 'superv', 
	    	'farerate', 'platesticker'];
	    	var pass_data = '';
	    	var total = 0;
	    	var error = false;

	    	fields_chkbx.forEach(function(e) {
	    		if($('#reg-tri-'+e).is(":checked")){
	    			pass_data += '&'+e+'='+$('#reg-tri-'+e).val();
	    			total++;
	    		} else {
	    			pass_data += '&'+e+'=0';
	    		}
	    	});

	    	// OTHERS PAYMENT AND DATES
	    	pass_data += '&others='+$('#reg-tri-others').val();

	    	date_loop.forEach(function(e) {
	    		if($('#tricycle-'+e).val() == ''){
	    			error = true;
	    			$('#tricycle-'+e).parent().addClass('has-error');
	    		} else {
	    			pass_data += '&'+e+'='+$('#tricycle-'+e).val();
	    		}
			});

	    	if(!error){
	    		if(total == 7){
	    			pass_data += '&tri_id='+$(this).attr('data-tri-id');
	    			// COMPLETE
		    		$.ajax({
						type: "POST",
						url: "common/db_call/db_trnsc-tricycle.php?action=complete_tricycle",
						data: 'id='+$(this).attr('data-id')+pass_data,
						success: function(msg){
							$('#view_tricycle').DataTable().destroy();
							$('.modal').modal('hide');
							viewTricycle();

							// SEND TEXT
							var data = JSON.parse(msg);

							$.ajax({
								type: "POST",
								url: "common/db_call/db_trnsc-tricycle.php?action=send_welcome_text",
								data: 'expiration='+data['expiration']+'&contact='+data['contact'],
								success: function(msg){
									alert(msg);
								}
							})
						}
					})
		    	} else {
		    		$.ajax({
						type: "POST",
						url: "common/db_call/db_trnsc-tricycle.php?action=pending_tricycle",
						data: 'id='+id+pass_data,
						success: function(msg){

							$('#view_tricycle').DataTable().destroy();
							$('.modal').modal('hide');
							viewTricycle();
						}
					})
		    	}
	    	}
	    });

}