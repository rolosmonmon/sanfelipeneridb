$(function () {
    viewMember();
})
function viewMember() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_trnsc-member.php?action=view_member",
		// data: pass_data,
		success: function(msg){
			$('#view_member tbody').html(msg);
			$('#view_member').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    addMember();
		    editMember();
		    deleteMember();

		    memberRegistration();
		    historyRegistration();
		}
	})
}
function historyRegistration() {
	$('.history-member').unbind('click').bind('click', function() {
		var mem_id = $(this).attr('data-mem-id');

		$('#modal-member-history').modal('show');
		$.ajax({
			type: "POST",
			url: "common/db_call/db_trnsc-member.php?action=view_member_registration",
			data: 'id='+mem_id,
			success: function(msg){
				$('#view_member_registration').DataTable().destroy();
				$('#view_member_registration tbody').html(msg);
				$('#view_member_registration').DataTable({
			      'paging'      : true,
			      'lengthChange': true,
			      'searching'   : true,
			      'ordering'    : true,
			      'info'        : true,
			      'autoWidth'   : false
			    });
			}
		})
	});
}
function addMember() {

	$('#member_add').unbind('click').bind('click', function() {
		$('#modal-add-member').modal('show');
		var default_field = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#member-'+e).val('');
		  $('#member-'+e).parent().removeClass('has-error');
		});
		$('.contact-validation').html('');

		// FORMAT
		$('#member-birthday').datepicker();
		$('#member-contact').inputmask('99999999999');
		$('#member-birthday').parent().parent().removeClass('has-error');
		$('#member-birthday').parent().parent().find('small').html('');
	});

	$('#save-add-member').unbind('click').bind('click', function() {
		var default_save = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'gender'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		$('.contact-validation').html('');
		default_save.forEach(function(e) {
			$('#member-'+e).parent().removeClass('has-error');

			if($('#member-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#member-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#member-'+e).val().trim();
			}
		});
		var contact = $('#member-contact').val();
		if(contact.replace('_', '').length != 11 && contact.replace('_', '').length != ''){
			error = true;
			$('#member-contact').parent().addClass('has-error');
			$('.contact-validation').html('Contact must be 11 digits.');
		}

		// GET MAX DATE
		$('#member-birthday').parent().parent().removeClass('has-error');
		$('#member-birthday').parent().parent().find('small').html('');
		
		var date_now = new Date().toJSON().slice(0,10).replace(/-/g,'/');
		var sliceDate = date_now.split('/');
		var yearsAgo18 = sliceDate[0]-18;
		var max_date = new Date(sliceDate[1]+'/'+sliceDate[2]+'/'+yearsAgo18);
		var birthdate = new Date($('#member-birthday').val());
		if(max_date < birthdate){
			error = true
			$('#member-birthday').parent().parent().addClass('has-error');
			$('#member-birthday').parent().parent().find('small').addClass('c-red').html('Member must be 18 years old and above.');
		}	

		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-member.php?action=add_member",
				data: pass_data,
				success: function(msg){
					$('#view_member').DataTable().destroy();
					$('.modal').modal('hide');
					viewMember();
				}
			})
		}
	});
}

function editMember() {
	$('.member-edit').unbind('click').bind('click', function() {
		
		var default_field = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'password'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#member-edit-'+e).parent().removeClass('has-error');
		});
		$('.contact-validation').html('');
		$('#member-edit-birthday').datepicker();
		$('#member-edit-contact').inputmask('99999999999');
		$('#member-edit-birthday').parent().parent().removeClass('has-error');
		$('#member-edit-birthday').parent().parent().find('small').html('');
		// POPULATE DATA
		var this_id = $(this).attr('data-id');
		$('#save-edit-member').attr('data-id', this_id);
		$.ajax({
			type: "POST",
			url: "common/db_call/db_trnsc-member.php?action=get_member",
			data: 'id='+this_id,
			success: function(msg){
				var data = JSON.parse(msg);
				$('#modal-edit-member').modal('show');
				$('#member-edit-first-name').val(data['first_name']);
				$('#member-edit-middle-name').val(data['middle_name']);
				$('#member-edit-last-name').val(data['last_name']);
				$('#member-edit-contact').val(data['contact']);
				$('#member-edit-birthday').val(data['birthday']);
				$('#member-edit-gender').val(data['gender']);

				if(data['member_status'] == 'Active'){

				}
			}
		})


	});

	$('#save-edit-member').unbind('click').bind('click', function() {
		var default_save = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'gender'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#member-edit-'+e).parent().removeClass('has-error');

			if($('#member-edit-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#member-edit-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#member-edit-'+e).val().trim();
			}
		});
		var contact = $('#member-edit-contact').val();
		if(contact.replace('_', '').length != 11 && contact.replace('_', '').length != ''){
			error = true;
			$('#member-edit-contact').parent().addClass('has-error');
			$('.contact-validation').html('Contact must be 11 digits.');
		}

		// GET MAX DATE
		$('#member-edit-birthday').parent().parent().removeClass('has-error');
		$('#member-edit-birthday').parent().parent().find('small').html('');
		
		var date_now = new Date().toJSON().slice(0,10).replace(/-/g,'/');
		var sliceDate = date_now.split('/');
		var yearsAgo18 = sliceDate[0]-18;
		var max_date = new Date(sliceDate[1]+'/'+sliceDate[2]+'/'+yearsAgo18);
		var birthdate = new Date($('#member-edit-birthday').val());
		if(max_date < birthdate){
			error = true
			$('#member-edit-birthday').parent().parent().addClass('has-error');
			$('#member-edit-birthday').parent().parent().find('small').addClass('c-red').html('Member must be 18 years old and above.');
		}	

		pass_data += '&id='+$(this).attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-member.php?action=update_member",
				data: pass_data,
				success: function(msg){
					$('#view_member').DataTable().destroy();
					$('.modal').modal('hide');
					viewMember();
				}
			})
		}
	});
}

function deleteMember() {
	$('.member-delete').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		$('#save-delete-member').attr('data-id', this_id);
		$('#modal-delete-member').modal('show');
	});

	$('#save-delete-member').unbind('click').bind('click', function(){
		$.ajax({
			type: "POST",
			url: "common/db_call/db_trnsc-member.php?action=delete_member",
			data: 'id='+$(this).attr('data-id'),
			success: function(msg){
				$('#view_member').DataTable().destroy();
				$('.modal').modal('hide');
				viewMember();
			}
		})
	})
}

function memberRegistration() {
	var date_loop = ['payment-date', 'effective-date', 'expiration'];
	var check_fields = ['regfee', 'regsticker', 'confirm', 'inspect', 'superv', 'farerate', 'platesticker'];
	
	// THIS IS FOR PENDING MEMBER
		$('.pending-member').unbind('click').bind('click', function() {
			$('#save-pending-member').attr('data-id', $(this).attr('data-id'));
			$('#save-pending-member').attr('data-mem-id', $(this).attr('data-mem-id'));
			$('#modal-pending-member').modal('show');
			
			// SHOW ORDER DETAILS
			$.ajax({
				type: "POST",
				url: "common/db_call/db_trnsc-member.php?action=view_pending_member",
				data: 'id='+$(this).attr('data-id'),
				success: function(msg){
					var data = JSON.parse(msg);
					check_fields.forEach(function(e) {
						if(data[e] != 0 && data[e] != null){
							$('#reg-mem-'+e).iCheck('check');
						} else {
							$('#reg-mem-'+e).iCheck('uncheck');
						}
					});
					$('#reg-mem-others').val(data['others']);

					date_loop.forEach(function(e) {
					  $('#member-'+e).val(data[e.replace('-', '_')]);
					});
				}
			})

			date_loop.forEach(function(e) {
			  $('#member-'+e).datepicker();
			  $('#member-'+e).parent().removeClass('has-error');
			});


			// SET EXPIRATION DATE
			$('#member-effective-date').focusout(function() {
				var this_date = $('#member-effective-date').val();
				var getYear = this_date.split('/');
				var next_year = parseInt(getYear[2]) +1;
				var expiration = getYear[0]+'/'+getYear[1]+'/'+next_year;
				console.log(next_year);
				var d = new Date(expiration);
 				d.setDate(d.getDate()-2);
 				var newMonth = d.getMonth()+1;
 				var newDay = d.getDate();
 				if(d.getMonth() < 10){
 					newMonth = '0'+newMonth;
 				}
 				if(d.getDate() < 10){
 					newDay = '0'+newDay;
 				}

 				var new_date = newMonth+'/'+newDay+'/'+d.getFullYear();
 				// console.log(new_date);
				$('#member-expiration').val(new_date);
			})
		});

		//Flat red color scheme for iCheck
	    $('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
	      checkboxClass: 'icheckbox_flat-green',
	      radioClass   : 'iradio_flat-green'
	    })

	    $('#save-pending-member').unbind('click').bind('click', function() {
	    	var fields_chkbx = ['regfee', 'regsticker', 'confirm', 'inspect', 'superv', 
	    	'farerate', 'platesticker'];
	    	var pass_data = '';
	    	var total = 0;
	    	var error = false;

	    	fields_chkbx.forEach(function(e) {
	    		if($('#reg-mem-'+e).is(":checked")){
	    			pass_data += '&'+e+'='+$('#reg-mem-'+e).val();
	    			total++;
	    		} else {
	    			pass_data += '&'+e+'=0';
	    		}
	    	});

	    	// OTHERS PAYMENT AND DATES
	    	pass_data += '&others='+$('#reg-mem-others').val();

	    	date_loop.forEach(function(e) {
	    		if($('#member-'+e).val() == ''){
	    			error = true;
	    			$('#member-'+e).parent().addClass('has-error');
	    		} else {
	    			pass_data += '&'+e+'='+$('#member-'+e).val();
	    		}
			});

	    	if(!error){
	    		if(total == 7){
	    			pass_data += '&member_id='+$(this).attr('data-mem-id');
	    			// COMPLETE
		    		$.ajax({
						type: "POST",
						url: "common/db_call/db_trnsc-member.php?action=complete_member",
						data: 'id='+$(this).attr('data-id')+pass_data,
						success: function(msg){
							$('#view_member').DataTable().destroy();
							$('.modal').modal('hide');
							viewMember();

							// SEND TEXT
							var data = JSON.parse(msg);
							$.ajax({
								type: "POST",
								url: "common/db_call/db_trnsc-member.php?action=send_welcome_text",
								data: 'expiration='+data['expiration']+'&contact='+data['contact'],
								success: function(msg){
									alert(msg);
								}
							})
						}
					})
		    	} else {
		    		$.ajax({
						type: "POST",
						url: "common/db_call/db_trnsc-member.php?action=pending_member",
						data: 'id='+$(this).attr('data-id')+pass_data,
						success: function(msg){
							$('#view_member').DataTable().destroy();
							$('.modal').modal('hide');
							viewMember();
						}
					})
		    	}
	    	}
	    });
}