$(function () {
    viewEnforcer();
})
function viewEnforcer() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-enforcer.php?action=view_enforcer",
		// data: pass_data,
		success: function(msg){
			$('#view_enforcer tbody').html(msg);
			$('#view_enforcer').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    addEnforcer();
		    editEnforcer();
		    deleteEnforcer();

		}
	})
}

function addEnforcer() {
	$('#enforcer_add').unbind('click').bind('click', function() {
		$('#modal-add-enforcer').modal('show');
		var default_field = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#enforcer-'+e).val('');
		  $('#enforcer-'+e).parent().removeClass('has-error');
		});
		$('.contact-validation').html('');
		$('#enforcer-contact').inputmask('99999999999');

		$('#enforcer-birthday').datepicker();
		$('#enforcer-birthday').parent().parent().removeClass('has-error');
		$('#enforcer-birthday').parent().parent().find('small').html('');
		
	});

	$('#save-add-enforcer').unbind('click').bind('click', function() {
		var default_save = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'gender'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#enforcer-'+e).parent().removeClass('has-error');

			if($('#enforcer-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#enforcer-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#enforcer-'+e).val().trim();
			}
		});
		$('.contact-validation').html('');
		var contact = $('#enforcer-contact').val();
		if(contact.replace('_', '').length != 11 && contact.replace('_', '').length != ''){
			error = true;
			$('#enforcer-contact').parent().addClass('has-error');
			$('.contact-validation').html('Contact must be 11 digits.');
		}

		// GET MAX DATE
		$('#enforcer-birthday').parent().parent().removeClass('has-error');
		$('#enforcer-birthday').parent().parent().find('small').html('');
		
		var date_now = new Date().toJSON().slice(0,10).replace(/-/g,'/');
		var sliceDate = date_now.split('/');
		var yearsAgo18 = sliceDate[0]-18;
		var max_date = new Date(sliceDate[1]+'/'+sliceDate[2]+'/'+yearsAgo18);
		var birthdate = new Date($('#enforcer-birthday').val());
		if(max_date < birthdate){
			error = true
			$('#enforcer-birthday').parent().parent().addClass('has-error');
			$('#enforcer-birthday').parent().parent().find('small').addClass('c-red').html('Enforcer must be 18 years old and above.');
		}

		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-enforcer.php?action=add_enforcer",
				data: pass_data,
				success: function(msg){
					$('#view_enforcer').DataTable().destroy();
					$('.modal').modal('hide');
					viewEnforcer();
				}
			})
		}
	});
}

function editEnforcer() {
	$('.enforcer-edit').unbind('click').bind('click', function() {
		
		var default_field = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'password'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#enforcer-edit-'+e).parent().removeClass('has-error');
		});
		$('.contact-validation').html('');
		$('#enforcer-edit-contact').inputmask('99999999999');
		$('#enforcer-edit-birthday').datepicker();

		$('#enforcer-edit-birthday').parent().parent().removeClass('has-error');
		$('#enforcer-edit-birthday').parent().parent().find('small').html('');

		// POPULATE DATA
		var this_id = $(this).attr('data-id');
		$('#save-edit-enforcer').attr('data-id', this_id);
		$.ajax({
			type: "POST",
			url: "common/db_call/db_mnt-enforcer.php?action=get_enforcer",
			data: 'id='+this_id,
			success: function(msg){
				var data = JSON.parse(msg);
				$('#modal-edit-enforcer').modal('show');
				$('#enforcer-edit-first-name').val(data['first_name']);
				$('#enforcer-edit-middle-name').val(data['middle_name']);
				$('#enforcer-edit-last-name').val(data['last_name']);
				$('#enforcer-edit-contact').val(data['contact']);
				$('#enforcer-edit-birthday').val(data['birthday']);
				$('#enforcer-edit-gender').val(data['gender']);
			}
		})


	});

	$('#save-edit-enforcer').unbind('click').bind('click', function() {
		var default_save = ['first-name', 'middle-name', 'last-name', 'contact', 
			'birthday', 'gender'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#enforcer-edit-'+e).parent().removeClass('has-error');

			if($('#enforcer-edit-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#enforcer-edit-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#enforcer-edit-'+e).val().trim();
			}
		});
		$('.contact-validation').html('');
		var contact = $('#enforcer-edit-contact').val();
		if(contact.replace('_', '').length != 11 && contact.replace('_', '').length != ''){
			error = true;
			$('#enforcer-edit-contact').parent().addClass('has-error');
			$('.contact-validation').html('Contact must be 11 digits.');
		}

		// GET MAX DATE
		$('#enforcer-edit-birthday').parent().parent().removeClass('has-error');
		$('#enforcer-edit-birthday').parent().parent().find('small').html('');
		
		var date_now = new Date().toJSON().slice(0,10).replace(/-/g,'/');
		var sliceDate = date_now.split('/');
		var yearsAgo18 = sliceDate[0]-18;
		var max_date = new Date(sliceDate[1]+'/'+sliceDate[2]+'/'+yearsAgo18);
		var birthdate = new Date($('#enforcer-edit-birthday').val());
		if(max_date < birthdate){
			error = true
			$('#enforcer-edit-birthday').parent().parent().addClass('has-error');
			$('#enforcer-edit-birthday').parent().parent().find('small').addClass('c-red').html('Enforcer must be 18 years old and above.');
		}

		pass_data += '&id='+$(this).attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-enforcer.php?action=update_enforcer",
				data: pass_data,
				success: function(msg){
					$('#view_enforcer').DataTable().destroy();
					$('.modal').modal('hide');
					viewEnforcer();
				}
			})
		}
	});
}

function deleteEnforcer() {
	$('.enforcer-delete').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		$('#save-delete-enforcer').attr('data-id', this_id);
		$('#modal-delete-enforcer').modal('show');
	});

	$('#save-delete-enforcer').unbind('click').bind('click', function(){
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-enforcer.php?action=delete_enforcer",
				data: 'id='+$(this).attr('data-id')+'&deleted_by='+$('.user-id').attr('data-id'),
				success: function(msg){
					$('#view_enforcer').DataTable().destroy();
					$('.modal').modal('hide');
					viewEnforcer();
				}
			})
	})
}