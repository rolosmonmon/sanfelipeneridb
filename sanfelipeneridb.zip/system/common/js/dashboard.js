$(function () {
    smsFunctions();
})
function viewUsers() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_dashboard.php?action=view_users",
		// data: pass_data,
		success: function(msg){
			$('#list_user tbody').html(msg);
			$('#list_user').DataTable({
		      'paging'      : true,
		      'lengthChange': false,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    $('.user-admin-count').html($('#list_user').DataTable().data().count()/2);
		}
	})
}

function viewMembers() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_dashboard.php?action=view_members",
		// data: pass_data,
		success: function(msg){
			$('#list_members tbody').html(msg);
			$('#list_members').DataTable({
		      'paging'      : true,
		      'lengthChange': false,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    $('.member-count').html($('#list_members').DataTable().data().count()/2);
		}
	})
}

function smsFunctions() {
	// $('#modal-dashboard').modal('show');
	$.ajax({
		type: "GET",
		url: "common/db_call/db_dashboard.php?action=sms_functions",
		// data: pass_data,
		success: function(msg){
			// alert('Welcome to Dashboard');
			viewUsers();
    		viewMembers();
    		
    		console.log(msg);
			// $('#list_members tbody').html(msg);
			// $('#list_members').DataTable({
		 //      'paging'      : true,
		 //      'lengthChange': false,
		 //      'searching'   : true,
		 //      'ordering'    : true,
		 //      'info'        : true,
		 //      'autoWidth'   : false
		 //    });
		 //    $('.member-count').html($('#list_members').DataTable().data().count()/2);
		}
	})
}