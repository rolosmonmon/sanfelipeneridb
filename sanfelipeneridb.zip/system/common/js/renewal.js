$(function () {
    viewYearlyRegistration();

    $('[href="#tab_member"]').unbind('click').bind('click', function() {
    	$('#view_yearly_registration').DataTable().destroy();
    	viewYearlyRegistration();
    });
    $('[href="#tab_tricycle"]').unbind('click').bind('click', function() {
    	$('#view_renewal_franchise').DataTable().destroy();
    	viewRenewalFranchise();
    });

})

// TODA NAME
function viewYearlyRegistration() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_trnsc-renewal.php?action=view_yearly_registration",
		// data: pass_data,
		success: function(msg){
			$('#view_yearly_registration tbody').html(msg);
			$('#view_yearly_registration').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    renewYearlyRegistration();

		}
	})
}
function renewYearlyRegistration() {
	var date_loop = ['payment-date', 'effective-date', 'expiration'];
	var check_fields = ['regfee', 'regsticker', 'confirm', 'inspect', 'superv', 'farerate', 'platesticker'];
	
	$('.renew-member').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-member-id');
		$('#save-renew-member').attr('data-member-id', this_id);

		date_loop.forEach(function(e) {
			  $('#renew-member-'+e).val('');
			  $('#renew-member-'+e).datepicker();
			  $('#renew-member-'+e).parent().removeClass('has-error');
			});


		// SET EXPIRATION DATE
		$('#renew-member-effective-date').focusout(function() {
			var this_date = $('#renew-member-effective-date').val();
			var getYear = this_date.split('/');
			var next_year = parseInt(getYear[2]) +1;
			var expiration = getYear[0]+'/'+getYear[1]+'/'+next_year;

			var d = new Date(expiration);
				d.setDate(d.getDate()-2);
				var newMonth = d.getMonth()+1;
				var newDay = d.getDate();
				if(d.getMonth() < 10){
					newMonth = '0'+newMonth;
				}
				if(d.getDate() < 10){
					newDay = '0'+newDay;
				}

				var new_date = newMonth+'/'+newDay+'/'+d.getFullYear();
				// console.log(new_date);
			$('#renew-member-expiration').val(new_date);
		})

		// ICHECK
		//Flat red color scheme for iCheck
	    $('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
	      checkboxClass: 'icheckbox_flat-green',
	      radioClass   : 'iradio_flat-green'
	    })

		$('#modal-renew-member').modal('show');
	});

	$('#save-renew-member').unbind('click').bind('click', function(){
		var pass_data = 'member_id='+$(this).attr('data-member-id');
		
		var fields_chkbx = ['regfee', 'regsticker', 'confirm', 'inspect', 'superv', 
	    	'farerate', 'platesticker'];
    	var error = false;

    	fields_chkbx.forEach(function(e) {
    		if($('#renew-mem-'+e).is(":checked")){
    			pass_data += '&'+e+'='+$('#renew-mem-'+e).val();
    		} else {
    			pass_data += '&'+e+'=0';
    		}
    	});

    	// OTHERS PAYMENT AND DATES
    	pass_data += '&others='+$('#renew-mem-others').val();

    	date_loop.forEach(function(e) {
    		if($('#renew-member-'+e).val() == ''){
    			error = true;
    			$('#renew-member-'+e).parent().addClass('has-error');
    		} else {
    			pass_data += '&'+e+'='+$('#renew-member-'+e).val();
    		}
		});

	    if(!error){
			$.ajax({
					type: "POST",
					url: "common/db_call/db_trnsc-renewal.php?action=renew_member",
					data: pass_data,
					success: function(msg){
						$('#view_yearly_registration').DataTable().destroy();
						$('.modal').modal('hide');
						viewYearlyRegistration();
					}
				});
	    }
	})
}

// USER ADMIN
function viewRenewalFranchise() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_trnsc-renewal.php?action=view_renewal_franchise",
		// data: pass_data,
		success: function(msg){
			$('#view_renewal_franchise tbody').html(msg);
			$('#view_renewal_franchise').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    renewRenewalFranchise();

		}
	})
}
function renewRenewalFranchise() {
	var date_loop = ['payment-date', 'effective-date', 'expiration'];
	var check_fields = ['superv', 'farerate'];
	
	$('.renew-tricycle').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-tri-id');
		$('#save-renew-tricycle').attr('data-tri-id', this_id);

		date_loop.forEach(function(e) {
			  $('#renew-tricycle-'+e).val('');
			  $('#renew-tricycle-'+e).datepicker();
			  $('#renew-tricycle-'+e).parent().removeClass('has-error');
			});


		// SET EXPIRATION DATE
		$('#renew-tricycle-effective-date').focusout(function() {
			var this_date = $('#renew-tricycle-effective-date').val();
			var getYear = this_date.split('/');
			var next_year = parseInt(getYear[2]) +2;
			var expiration = getYear[0]+'/'+getYear[1]+'/'+next_year;

			var d = new Date(expiration);
				d.setDate(d.getDate()-2);
				var newMonth = d.getMonth()+1;
				var newDay = d.getDate();
				if(d.getMonth() < 10){
					newMonth = '0'+newMonth;
				}
				if(d.getDate() < 10){
					newDay = '0'+newDay;
				}

				var new_date = newMonth+'/'+newDay+'/'+d.getFullYear();
				// console.log(new_date);
			$('#renew-tricycle-expiration').val(new_date);
		})

		// ICHECK
		//Flat red color scheme for iCheck
	    $('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
	      checkboxClass: 'icheckbox_flat-green',
	      radioClass   : 'iradio_flat-green'
	    })

		$('#modal-renew-tricycle').modal('show');
	});

	$('#save-renew-tricycle').unbind('click').bind('click', function(){
		var pass_data = 'tricycle_id='+$(this).attr('data-tri-id');
		
		var fields_chkbx = ['superv', 'farerate'];
    	var error = false;

    	fields_chkbx.forEach(function(e) {
    		if($('#renew-tri-'+e).is(":checked")){
    			pass_data += '&'+e+'='+$('#renew-tri-'+e).val();
    		} else {
    			pass_data += '&'+e+'=0';
    		}
    	});

    	// OTHERS PAYMENT AND DATES
    	pass_data += '&others='+$('#renew-tri-others').val();

    	date_loop.forEach(function(e) {
    		if($('#renew-tricycle-'+e).val() == ''){
    			error = true;
    			$('#renew-tricycle-'+e).parent().addClass('has-error');
    		} else {
    			pass_data += '&'+e+'='+$('#renew-tricycle-'+e).val();
    		}
		});

	    if(!error){
			$.ajax({
					type: "POST",
					url: "common/db_call/db_trnsc-renewal.php?action=renew_tricycle",
					data: pass_data,
					success: function(msg){
						$('#view_renewal_franchise').DataTable().destroy();
						$('.modal').modal('hide');
						viewRenewalFranchise();
					}
				});
	    }
	})
}