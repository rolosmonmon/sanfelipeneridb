$(function () {
    viewToda();
})
function viewToda() {
	$.ajax({
		type: "GET",
		url: "common/db_call/db_mnt-toda.php?action=view_toda",
		// data: pass_data,
		success: function(msg){
			$('#view_toda tbody').html(msg);
			$('#view_toda').DataTable({
		      'paging'      : true,
		      'lengthChange': true,
		      'searching'   : true,
		      'ordering'    : true,
		      'info'        : true,
		      'autoWidth'   : false
		    });
		    addToda();
		    editToda();
		    deleteToda();

		}
	})
}

function addToda() {
	$('#toda_add').unbind('click').bind('click', function() {
		$('#modal-add-toda').modal('show');
		var default_field = ['toda-name'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#toda-'+e).val('');
		  $('#toda-'+e).parent().removeClass('has-error');
		});

		$('#toda-toda-color').val('#000000');
	});

	$('#save-add-toda').unbind('click').bind('click', function() {
		var default_save = ['toda-name', 'toda-color'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#toda-'+e).parent().removeClass('has-error');

			if($('#toda-'+e).val().trim() == '' && e != 'middle-name'){
				error = true;
				$('#toda-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#toda-'+e).val().trim();
			}
		});

		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-toda.php?action=add_toda",
				data: pass_data,
				success: function(msg){
					$('#view_toda').DataTable().destroy();
					$('.modal').modal('hide');
					viewToda();
				}
			})
		}
	});
}

function editToda() {
	$('.toda-edit').unbind('click').bind('click', function() {
		
		var default_field = ['toda-name'];
		// EMPTY FIELDS AND REMOVE VALIDATIONS
		default_field.forEach(function(e) {
		  $('#toda-edit-'+e).parent().removeClass('has-error');
		});

		// POPULATE DATA
		var this_id = $(this).attr('data-id');
		$('#save-edit-toda').attr('data-id', this_id);
		$.ajax({
			type: "POST",
			url: "common/db_call/db_mnt-toda.php?action=get_toda",
			data: 'id='+this_id,
			success: function(msg){
				var data = JSON.parse(msg);
				$('#modal-edit-toda').modal('show');
				$('#toda-edit-toda-name').val(data['toda_name']);
				$('#toda-edit-toda-color').val(data['toda_color']);
			}
		})


	});

	$('#save-edit-toda').unbind('click').bind('click', function() {
		var default_save = ['toda-name', 'toda-color'];
		var error = false;
		var pass_data = '';
		// CHECK VALIDATION
		default_save.forEach(function(e) {
			$('#toda-edit-'+e).parent().removeClass('has-error');

			if($('#toda-edit-'+e).val().trim() == ''){
				error = true;
				$('#toda-edit-'+e).parent().addClass('has-error');
			} else {
				pass_data +='&'+e+'='+$('#toda-edit-'+e).val().trim();
			}
		});
		pass_data += '&id='+$(this).attr('data-id');
		if(!error){
			$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-toda.php?action=update_toda",
				data: pass_data,
				success: function(msg){
					$('#view_toda').DataTable().destroy();
					$('.modal').modal('hide');
					viewToda();
				}
			})
		}
	});
}

function deleteToda() {
	$('.toda-delete').unbind('click').bind('click', function() {
		var this_id = $(this).attr('data-id');
		$('#save-delete-toda').attr('data-id', this_id);
		$('#modal-delete-toda').modal('show');
	});

	$('#save-delete-toda').unbind('click').bind('click', function(){
		$.ajax({
				type: "POST",
				url: "common/db_call/db_mnt-toda.php?action=delete_toda",
				data: 'id='+$(this).attr('data-id')+'&deleted_by='+$('.user-id').attr('data-id'),
				success: function(msg){
					$('#view_toda').DataTable().destroy();
					$('.modal').modal('hide');
					viewToda();
				}
			})
	})
}