<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
$filename='toda_db.pdf';
header("Content-disposition:attachment;filename=$filename");
header('Content-type:application/pdf');
readfile($filename);
?>
</body>
</html>



    <!-- TABLE -->
  <!--   <section class="content">
        <div class="row pull-right col-xs-4 p-b-15">
            <button type="button" id="enforcer_add" class="btn btn-block btn-default">
                Add Enforcer
            </button>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <table id="view_enforcer" class="table table-bordered table-hover">
                            <thead>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Birthday</th>
                                <th>Gender</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                
                            </tbody>
                            <tfoot>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Birthday</th>
                                <th>Gender</th>
                                <th>Action</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
 -->
</div>
<?php include('common/footer.php'); ?>
<?php include('modal/maintenance/enforcer_modal.php'); ?>
<script type="text/javascript">
<?php include('common/js/enforcer.js'); ?>
</script>